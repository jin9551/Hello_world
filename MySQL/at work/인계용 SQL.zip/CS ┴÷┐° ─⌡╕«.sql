# 머지포인트 이용 경험이 있는 회원 정보 검색
SELECT oid, id, name, phone, companyRef, creDateTime AS 가입일, osType, state,
    (
        SELECT SUM(oid)
        FROM tbl_payment
        WHERE
            memberRef = a.oid
            AND useState IN (2,3)
    )
FROM tbl_member AS a
WHERE
    oid IN (
        SELECT memberRef
        FROM tbl_payment
        WHERE useState IN (2,3)
        )
ORDER BY creDateTime