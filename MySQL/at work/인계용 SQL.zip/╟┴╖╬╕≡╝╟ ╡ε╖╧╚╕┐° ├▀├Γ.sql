SELECT promotionRef, groupRef, points, salePrice, name, COUNT( memberRef )
FROM tbl_pointCode a
WHERE state =3
AND promotionRef =180

GROUP BY groupRef