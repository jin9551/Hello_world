select promotionRef,memberRef,memberName, 
memberPhone, 
(select id from tbl_member where memberRef = oid) as id, 
(select name from tbl_promotion where promotionRef = oid) as 프로모션, 
sum(points) as 총등록금액,
count(oid) as 등록횟수
from tbl_pointCode
where  state = 3 -- 등록완료
and registDateTime >= '2020-09-01 00:00:00' 
and registDateTime < '2020-12-01 00:00:00'
group by promotionRef, memberRef
having 등록횟수 > 4  and 총등록금액 >= 5000000



select year(useDateTime) as year, month(useDateTime) as month, memberRef,memberName, memberPhone, (select id from tbl_member where memberRef = oid) as id, shopName, SUM(pointPrice) as points
from tbl_order
where consummerRef > 0 
and state = 2
and pointPrice > 0
AND useDateTime >= "2020-09-01 00:00:00"
AND useDateTime < "2020-12-01 00:00:00"
group by year,month, memberRef, consummerRef 
having points >= 10000000



select promotionRef,memberRef,memberName, 
memberPhone, 
(select id from tbl_member where memberRef = oid) as id, 
(select name from tbl_promotion where promotionRef = oid) as 프로모션, 
code,
points as 등록금액
from tbl_pointCode
where
memberRef IN (76696,120708,121110,134566,139653,183298,188017,197691,278660,334664,370374,193894,369793,161184,211510,233328,261158,440601)
and state = 3
and registDateTime >= '2020-09-01 00:00:00' 
and registDateTime < '2020-12-01 00:00:00'
order by memberRef


select year(useDateTime) as year ,date(useDateTime) as date, memberRef,memberName, shopName, case when state = 2 then '결제' else '취소' end as 상태, pointPrice as 사용금액
from tbl_order
where memberRef IN (76696,120708,121110,134566,139653,183298,188017,197691,278660,334664,370374,193894,369793,161184,211510,233328,261158,440601)
and consummerRef > 0
and state IN (2,5)
and pointPrice > 0
AND useDateTime >= "2020-09-01 00:00:00"
AND useDateTime < "2020-12-01 00:00:00"