
from <- 얘 옆에 적힌 테이블이 sql로 조회해야하는 테이블입니다.

머플 사용 내역



select  a.oid, a.memberRef,
(select  level from tbl_vip where a.memberRef = recommendee) as level, 
(select date(registDateTime) from tbl_vip where a.memberRef = recommendee) as 등록일시, 
a.shopName,
 a.price ,
 a.giftCode,
(select channel from tbl_vip where a.memberRef = recommendee) as 채널, b.state, b.completeDateTime

from tbl_pg_payment a

left outer join tbl_benefitPayment b on a.giftCode = b.code
where a.state = 1
and a.creDateTime>= "2020-07-08 00:00:00"
AND a.creDateTime < "2020-07-09 00:00:00"
order by date(b.completeDateTime)


머플콘사

select year(b.completeDateTime), date(b.completeDateTime), a.oid, b.franchiseID,
a.shopName,
sum(a.price) ,
b.state, count(a.oid) as 결제횟수
from tbl_pg_payment a
left outer join tbl_benefitPayment b on a.giftCode = b.code
where a.state = 1
and a.creDateTime>= "2020-07-08 00:00:00"
AND a.creDateTime < "2020-07-09 00:00:00"
group by year(b.completeDateTime), date(b.completeDateTime), b.franchiseID, b.state




----포인트관리


포인트관리/포인트일반


SELECT YEAR( useDateTime ) AS 사용년도, MONTH( useDateTime ) AS 사용월, SUM( accPoints ) AS 적립포인트, SUM( buyPoints ) AS 구매포인트, SUM( tampingPoints ) AS 탬핑포인트

FROM tbl_use

WHERE 
-- consummerRef=0은 포인트 일반, >0은 포인트관리
consummerRef = 0
AND settlementState IN (2,3)
AND useType NOT IN (2, 3)
AND useDateTime >= "2018-01-01 00:00:00"
AND useDateTime < "2020-07-09 00:00:00"
GROUP BY YEAR( useDateTime ) , MONTH( useDateTime )


절대값

select YEAR( useDateTime ) AS 사용년도, date( useDateTime ) AS 사용일, SUM( accPoints ) AS 적립포인트, SUM( buyPoints ) AS 구매포인트, SUM( tampingPoints ) AS 탬핑포인트
from tbl_use
where useDateTime >= '2020-07-08 00:00:00' 
AND useDateTime < '2020-07-09 00:00:00'
GROUP BY YEAR( useDateTime ) , date( useDateTime )



만료 포인트 조사

SELECT *
FROM `tbl_pointsHistory`
WHERE `type` =3
AND totalPoints = 0
AND  creDateTime >= "2020-07-08 00:00:00"
AND  creDateTime < "2020-07-09 00:00:00"


회수

SELECT *

FROM `tbl_pointsHistory`

WHERE `reason` LIKE '%회수%'
# WHERE 'reason' LIKE '%이동%'
AND totalPoints = 0
AND  creDateTime >= "2020-07-08 00:00:00"
AND  creDateTime < "2020-07-09 00:00:00"




---콘사콘사

프랜

SELECT YEAR( useDateTime ) AS 사용년도, DATE( useDateTime ) AS 일별, consummerRef, shopName, SUM( pointPrice ) AS 사용금액, (SELECT producerRef
            FROM tbl_giftConsummer
            WHERE
                consummerRef = oid
        ) as 콘사1pays2smart

FROM tbl_order

WHERE consummerRef >0
    AND state IN (2,5)
    AND useDateTime >= '2020-07-08 00:00:00'
    AND useDateTime < '2020-07-09 00:00:00'
GROUP BY YEAR( useDateTime ) , DATE( useDateTime ) , consummerRef



프랜차이즈 취소금액


SELECT YEAR( useDateTime ) AS 사용년도, MONTH(useDateTime) AS 월, consummerRef, shopName, SUM( pointPrice ) AS 취소금액, (SELECT producerRef
            FROM tbl_giftConsummer
            WHERE
                consummerRef = oid
        ) as 콘사1pays2smart
FROM tbl_order
WHERE consummerRef >0
    AND state IN (5)
   AND useDateTime >= "2020-07-01 00:00:00"
    AND useDateTime < "2020-07-09 00:00:00"
GROUP BY YEAR( useDateTime ), MONTH(useDateTime), consummerRef


일반


SELECT YEAR( useDateTime ) AS 사용년도, DATE( useDateTime ) AS 일별, SUM( orderPrice ) AS 사용금액
FROM tbl_order
WHERE consummerRef = 0
    AND state IN (2,5)
    AND useDateTime >= "2020-07-01 00:00:00"
    AND useDateTime < "2020-07-09 00:00:00"
GROUP BY YEAR( useDateTime ) , DATE( useDateTime ) 


일반취소

SELECT MONTH( creDateTime ) AS 월, SUM( orderPrice ) AS 누적취소금액

FROM `tbl_payShop`

WHERE `consummerRef` =0
AND `settlementState` =5
AND `useState` =4
AND `creDateTime` >= '2020-07-01 00:00:00'
AND `creDateTime` < '2020-07-09 00:00:00'
GROUP BY YEAR(creDateTime), MONTH(creDateTime)

