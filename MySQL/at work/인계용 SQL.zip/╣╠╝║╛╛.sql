##############################################################################################################################################################################
머플 사용 내역

select  a.oid, a.memberRef,
(select  level from tbl_vip where a.memberRef = recommendee) as level, 
(select date(registDateTime) from tbl_vip where a.memberRef = recommendee) as 등록일시, 
a.shopName,
 a.price ,
 a.giftCode,
(select channel from tbl_vip where a.memberRef = recommendee) as 채널, b.state, b.completeDateTime
from tbl_pg_payment a
left outer join tbl_benefitPayment b on a.giftCode = b.code
where a.state = 1
and a.creDateTime>= "2020-09-01 00:00:00"
AND a.creDateTime < "2020-09-02 00:00:00"
order by date(b.completeDateTime)





select  a.oid, a.memberRef,
(select  level from tbl_vip where a.memberRef = recommendee) as level, 
(select date(registDateTime) from tbl_vip where a.memberRef = recommendee) as 등록일시, 
a.shopName,
 a.price ,
 a.giftCode,
(select channel from tbl_vip where a.memberRef = recommendee) as 채널, b.state, b.completeDateTime
from tbl_pg_payment a
left outer join tbl_benefitPayment b on a.giftCode = b.code
where
and b.franchiseID IN (56,94)
and a.state = 1
and a.creDateTime>= "2020-07-06 00:00:00"
AND a.creDateTime < "2020-07-07 00:00:00"
order by date(b.completeDateTime)

머플콘사
select year(b.completeDateTime), date(b.completeDateTime), a.oid, b.franchiseID,
a.shopName,
sum(a.price) ,
b.state,b.paymentType as 결제종류, count(a.oid) as 결제횟수
from tbl_pg_payment a
left outer join tbl_benefitPayment b on a.giftCode = b.code
where a.state = 1
and a.creDateTime>= "2020-08-07 00:00:00"
AND a.creDateTime < "2020-08-10 00:00:00"
group by year(b.completeDateTime), date(b.completeDateTime), b.state

union all

select year(b.completeDateTime), date(b.completeDateTime), a.oid, b.franchiseID,
a.shopName,
sum(a.price) ,
b.state,b.paymentType as 결제종류, count(a.oid) as 결제횟수
from tbl_pg_payment a
left outer join tbl_benefitPayment b on a.giftCode = b.code
where a.state = 1
and a.creDateTime>= "2020-09-01 00:00:00"
AND a.creDateTime < "2020-09-02 00:00:00"
group by year(b.completeDateTime), date(b.completeDateTime), b.franchiseID, b.state
#######################################################

기준 1
전일 6회 이상 결제 and 전일 결제 금액 40만원 이상

기준 2
전일 100만원 이상 결제 및 일 전일 10회 이상 결제

저 기준들로
-oid
-연락처
-전일 머지플러스 결제 내역

매일 전달주시는 데이터에 포함 가능할까유?!
기준 1과 2 각각 추출이여!

1. oid 추출
SELECT a.oid, a.name, a.phone, t.q
FROM tbl_member a, 
(select memberID, sum(paycoPrice) as q
from tbl_benefitPayment b 
where state like 'complete' 
and completeDateTime between '2020-08-31' and '2020-08-31 23:59:59' 
group by memberID having count(b.oid)>5 and q >= 400000) as t
WHERE a.oid = t.memberID;


2. oid 추출
select a.oid, a.name, a.phone, t.q
from tbl_member a, (select memberID, sum(paycoPrice) as q
from tbl_benefitPayment b 
where state like 'complete' 
and completeDateTime between '2020-08-31' and '2020-08-31 23:59:59' 
group by memberID having count(b.oid)>10 and q >= 1000000) as t
where a.oid = t.memberID;


3. 결제내역 추출
select oid,memberID, paymentType, state, (select name from tbl_giftConsummer where franchiseID = oid) as 매장명, code, paycoPrice as 결제금액, completeDateTime
from tbl_benefitPayment
where memberID IN (299184)


####################################################################################################################################################################################
폐기
-- #결제횟수
-- SELECT DATE(useDateTime) as 일, COUNT(oid) 결제횟수 FROM `tbl_order` WHERE useDateTime >= '2020-06-29 00:00:00' AND useDateTime < '2020-06-30 00:00:00'
-- group by  DATE(useDateTime)

-- #결제자수
-- SELECT DATE(useDateTime) as 일, COUNT(distinct memberRef) as 결제자수 FROM `tbl_order` WHERE useDateTime >= '2020-06-29 00:00:00' AND useDateTime < '2020-06-30 00:00:00'
-- group by  DATE(useDateTime)

-- #사용금액(결제+취소)
-- SELECT DATE(useDateTime) as 일, SUM(orderPrice) as 사용금액 FROM `tbl_order` WHERE useDateTime >= '2020-06-29 00:00:00' AND useDateTime < '2020-06-30 00:00:00'
-- group by  DATE(useDateTime)



####################################################################################################################################################################################
#취소금액  #프랜차이즈와 일반매장은 따로 구해야할듯
#useType = 6은 프랜차이즈

SELECT YEAR( useDateTime ) AS 사용년도, MONTH( useDateTime ) AS 사용월, SUM( accPoints ) AS 적립포인트, SUM( buyPoints ) AS 구매포인트, SUM( tampingPoints ) AS 탬핑포인트
FROM tbl_use
WHERE 
consummerRef > 0
AND settlementState IN (2,3)
AND useType NOT IN (2, 3)
AND useDateTime >= "2018-01-01 00:00:00"
AND useDateTime < "2020-09-07 00:00:00"
GROUP BY YEAR( useDateTime ) , MONTH( useDateTime )



select YEAR( useDateTime ) AS 사용년도, date( useDateTime ) AS 사용일, SUM( accPoints ) AS 적립포인트, SUM( buyPoints ) AS 구매포인트, SUM( tampingPoints ) AS 탬핑포인트
from tbl_use
where useDateTime >= '2020-10-19 00:00:00' 
AND useDateTime < '2020-10-26 00:00:00'
GROUP BY YEAR( useDateTime ) , date( useDateTime )


## 폐기
-- # 적립포인트 일일 발행현황 - 박미성
-- SELECT YEAR(creDateTime) AS 발행년도, DATE(creDateTime) AS 발행월, SUM(accPoints) AS 적립포인트
-- FROM tbl_pointsHistory
-- WHERE
--     type = 1
--     AND DATE(creDateTime) >= "2020-05-07 00:00:00"
--     AND DATE(creDateTime) < "2020-05-22 00:00:00"
-- GROUP BY
--     YEAR(creDateTime), DATE(creDateTime)


# 만료 포인트 조사

SELECT *
FROM `tbl_pointsHistory`
WHERE `type` =3
AND totalPoints = 0
AND  creDateTime >= "2020-09-01 00:00:00"
AND  creDateTime < "2020-09-02 00:00:00"


#회수포인트 조사
SELECT *
FROM `tbl_pointsHistory`
WHERE `reason` LIKE '%회수%'
# WHERE 'reason' LIKE '%이동%'
AND totalPoints = 0
AND  creDateTime >= "2020-11-01 00:00:00"
AND  creDateTime < "2020-12-01 00:00:00"



#######################################################################################################################################################################

12.18 추가
일별로 브랜드별 결제자수와 결제횟수용!

# 일별 프렌차이즈 포인트량. (사용+취소) 
SELECT YEAR( useDateTime ) AS 사용년도, DATE( useDateTime ) AS 일별, consummerRef, shopName, SUM( pointPrice ) AS 사용금액, (SELECT producerRef
            FROM tbl_giftConsummer
            WHERE
                consummerRef = oid
        ) as 콘사1pays2smart
FROM tbl_order
WHERE consummerRef >0
    AND state IN (2,5)
    AND useDateTime >= '2020-09-01 00:00:00'
    AND useDateTime < '2020-09-02 00:00:00'
GROUP BY YEAR( useDateTime ) , DATE( useDateTime ) , consummerRef




#프랜차이즈 취소금액
SELECT YEAR( useDateTime ) AS 사용년도, MONTH(useDateTime) AS 월, consummerRef, shopName, SUM( pointPrice ) AS 취소금액, (SELECT producerRef
            FROM tbl_giftConsummer
            WHERE
                consummerRef = oid
        ) as 콘사1pays2smart
FROM tbl_order
WHERE consummerRef >0
    AND state IN (5)
    AND useDateTime >= '2020-09-01 00:00:00'
    AND useDateTime < '2020-09-02 00:00:00'
GROUP BY YEAR( useDateTime ), MONTH(useDateTime), consummerRef

#일반매장 일별 총 포인트량
SELECT YEAR( useDateTime ) AS 사용년도, DATE( useDateTime ) AS 일별, SUM( orderPrice ) AS 사용금액
FROM tbl_order
WHERE consummerRef = 0
    AND state IN (2,5)
    AND useDateTime >= '2020-09-01 00:00:00'
    AND useDateTime < '2020-09-02 00:00:00'
GROUP BY YEAR( useDateTime ) , DATE( useDateTime ) 

#일반매장 취소금액

SELECT MONTH( creDateTime ) AS 월, SUM( orderPrice ) AS 누적취소금액
FROM `tbl_payShop`
WHERE `consummerRef` =0
AND `settlementState` =5
AND `useState` =4
AND `creDateTime` >= '2020-09-01 00:00:00'
AND `creDateTime` < '2020-09-03 00:00:00'
GROUP BY YEAR(creDateTime), MONTH(creDateTime)


###################################################################################
#신규최초


select oid, promotionRef, (select name from tbl_promotion where promotionRef = oid) as 프로모션, code, name, points, registDateTime, memberRef, memberName, (select creDateTime from tbl_member where memberRef = oid) as 가입일시
from tbl_pointCode
where state =3 
and memberRef in (select oid from tbl_member where creDateTime  between '2020-04-28 00:00:00' and '2020-04-29 00:00:00'  )
AND registDateTime between '2020-04-28 00:00:00' AND '2020-04-29 00:00:00' 


########################################################################################################
#신규가입자가 등록한 최초 프로모션 코드

SELECT oid, 
promotionRef, 
(
select name 
from tbl_promotion 
where pcode.promotionRef = oid) as 프로모션명,
code,
(
SELECT groupName
FROM tbl_pointCodeGroup
WHERE oid = pcode.groupRef
) AS 금액권명, 
points, 
registDateTime AS 등록일시, 

memberRef, 
memberName,  
(
SELECT creDateTime
FROM tbl_member
WHERE oid = pcode.memberRef
) AS 가입일시

from tbl_pointCode as pcode

where pcode.memberRef IN
(
SELECT oid
FROM `tbl_member`
WHERE `creDateTime` >= '2020-02-11 00:00:00'
AND `creDateTime` < '2020-02-12 00:00:00'
)
AND registDateTime >= '2020-02-11 00:00:00' 
AND registDateTime < '2020-02-12 00:00:00' 

GROUP BY memberRef  #group by 의 특성을 이용함







########################################################################################################
#프로모션 관리
SELECT oid, promotionRef,(select name from tbl_promotion where pcode.promotionRef = oid) as 프로모션명, code, (
SELECT groupName
FROM tbl_pointCodeGroup
WHERE oid = pcode.groupRef
) AS 금액권명, points, registDateTime AS 등록일시
FROM `tbl_pointCode` AS pcode
WHERE `promotionRef`
IN (222,223,240,241,244,248,251,256,257,265,266,268,269,272,275,276,277)
AND state =3
AND registDateTime >= '2019-10-01 00:00:00' 
AND registDateTime < '2020-02-03 00:00:00' 




#########################################################################################################
SELECT oid, name, id, phone, creDateTime AS 가입일, gender, visitDateTime AS 최종방문일, state, osType, points,
    (
        SELECT MIN(registDateTime)
        FROM tbl_pointCode
        WHERE
            memberRef = a.oid
    ) AS 최초적립일,
    (
        SELECT promotionRef
        FROM tbl_pointCode
        WHERE
            memberRef = a.oid
            AND registDateTime =(SELECT min(registDateTime) from tbl_pointCode  where memberRef = a.oid)
    ) AS 최초적립,
    (
        SELECT COUNT(oid)
        FROM tbl_pointCode
        WHERE
            memberRef = a.oid 
    ) AS 적립횟수
FROM tbl_member AS a
WHERE oid IN (101624)
######최초등록 파악!!!!!!!!!!!!########

SELECT  oid, name,creDateTime AS 가입일, (

SELECT MIN( DATE(registDateTime) )
FROM tbl_pointCode
WHERE memberRef = a.oid
) AS 최초적립일, (

SELECT MIN( promotionRef )
FROM tbl_pointCode
WHERE memberRef = a.oid
) AS 최초적립프로모션, (

SELECT MIN( groupRef )
FROM tbl_pointCode
WHERE memberRef = a.oid
) AS 최초적립코드그룹,
(
SELECT COUNT(oid)
FROM tbl_pointCode
WHERE
memberRef = a.oid 
AND registDateTime >= '2019-07-01 00:00:00' 
AND registDateTime < '2019-10-01 00:00:00' 
) AS 적립횟수

FROM tbl_member AS a

WHERE oid IN ( #바우쳐를 XX월부터 XX사이에 등록한 사람들
SELECT memberRef
FROM tbl_pointCode
WHERE 
state =3
AND registDateTime >= '2019-07-01 00:00:00' 
AND registDateTime < '2019-10-01 00:00:00' 
)
GROUP BY oid


################################################################################################################



##################################################################################
#주 단위로 카운트
SELECT DATE_FORMAT(DATE_SUB(`useDateTime`, INTERVAL (DAYOFWEEK(`useDateTime`)-2) DAY), '%Y/%m/%d') as start,
 DATE_FORMAT(DATE_SUB(`useDateTime`, INTERVAL (DAYOFWEEK(`useDateTime`)-8) DAY), '%Y/%m/%d') as end, 
 DATE_FORMAT(`useDateTime`, '%Y%u') AS `date`, COUNT(distinct memberRef) 
 FROM tbl_order
 WHERE state IN (2,5)
  AND useDateTime >= "2020-06-22 00:00:00"
  AND useDateTime < "2020-06-29 00:00:00" 
 GROUP BY date


 SELECT DATE_FORMAT(DATE_SUB(`completeDateTime`, INTERVAL (DAYOFWEEK(`completeDateTime`)-2) DAY), '%Y/%m/%d') as start,
 DATE_FORMAT(DATE_SUB(`completeDateTime`, INTERVAL (DAYOFWEEK(`completeDateTime`)-8) DAY), '%Y/%m/%d') as end, 
 DATE_FORMAT(`completeDateTime`, '%Y%u') AS `date`, COUNT(distinct memberID) 
 FROM tbl_benefitPayment
 WHERE paymentType like 'normal' 
  and state LIKE 'complete'
  AND completeDateTime >= "2020-06-01 00:00:00"
  AND completeDateTime < "2020-07-01 00:00:00" 
 GROUP BY date


#############################################################################
-- 준호씨의 기묘한 의뢰 2020.04.22
SELECT MONTH(useDateTime), memberRef, (select phone from tbl_member a where a.oid = memberRef) as phone, (select year(birthday) from tbl_member a where a.oid=memberRef) as 생년,   COUNT(oid), count(distinct consummerRef)
FROM `tbl_order`
WHERE
memberRef not in  (select memberRef from tbl_order where consummerRef in (0,6,40,47))
and state =2
AND useDateTime >= "2020-03-01 00:00:00"
AND useDateTime < "2020-04-23 00:00:00"
GROUP BY  memberRef
having count(oid) > 20 and count(distinct consummerRef) >3 --조건 주의


##############################################################################
미성대리님의 랜덤 테스토


SELECT memberRef,memberName,sum(orderPrice) as 사용금액,
 count(oid) as 사용횟수, 
 (select sum(points) from tbl_pointCode b where state =3 and a.memberRef = b.memberRef and registDateTime between '2020-05-01 00:00:00' and '2020-05-31 23:59:59') as 등록금액,
 (select count(oid) from tbl_pointCode b where state =3 and a.memberRef = b.memberRef and registDateTime between '2020-05-01 00:00:00' and '2020-05-31 23:59:59') as 등록횟수, 
 (select sum(salePrice) from tbl_pointCode b where state =3 and a.memberRef = b.memberRef and registDateTime between '2020-05-01 00:00:00' and '2020-05-31 23:59:59') as 판매금액합, (select points from tbl_member where memberRef = oid) as 잔여포인트
 FROM tbl_order a
 WHERE  consummerRef > 0 and companyPoints = 0 and payPrice = 0 and state =2 and `useDateTime` between '2020-05-01 00:00:00' and '2020-05-31 23:59:59'
group by memberRef
order by memberRef



SELECT memberRef,memberName,sum(orderPrice) as 사용금액,
 count(oid)
 FROM tbl_order a
 WHERE consummerRef > 0 and companyPoints = 0 and payPrice = 0 and state =2 and `useDateTime` between '2020-05-01 00:00:00' and '2020-05-31 23:59:59'
group by memberRef
order by rand()
limit 500


select memberRef, memberName,
(select sum(orderPrice) from tbl_order a where  a.memberRef = b.memberRef and consummerRef > 0 and companyPoints = 0 and payPrice = 0 and state =2 and `useDateTime` between '2020-05-01 00:00:00' and '2020-05-31 23:59:59') as 사용금액,
(select count(oid) from tbl_order a where  a.memberRef = b.memberRef and consummerRef > 0 and companyPoints = 0 and payPrice = 0 and state =2 and `useDateTime` between '2020-05-01 00:00:00' and '2020-05-31 23:59:59') as 사용횟수,
 sum(points) as 등록금액,count(oid) as 등록횟수,sum(salePrice) as 총판매금액, (select points from tbl_member where memberRef = oid) as 잔여포인트
from tbl_pointCode b
where state =3 and registDateTime between '2020-05-01 00:00:00' and '2020-05-31 23:59:59'
group by memberRef
order by memberRef


SELECT COUNT( oid ) , (
SUM( points ) / COUNT( oid )
) AS 평균
FROM `tbl_member`
WHERE verification =1
AND state =1
AND creDateTime < '2020-06-01 00:00:00'


#사용 등록 없는 사람의 평균 잔여포인트
select count(oid), (SUM( points ) / COUNT( oid )
) AS 평균
from tbl_member
where oid not in (select memberRef from tbl_pointCode where state =3 and registDateTime between '2020-05-01 00:00:00' and '2020-05-31 23:59:59')
and oid not in (select memberRef from tbl_order where `useDateTime` between '2020-05-01 00:00:00' and '2020-05-31 23:59:59')
and verification = 1
AND state =1
AND creDateTime < '2020-06-01 00:00:00'


1. 주간 머플 결제자
 SELECT DATE_FORMAT(DATE_SUB(`completeDateTime`, INTERVAL (DAYOFWEEK(`completeDateTime`)-2) DAY), '%Y/%m/%d') as start,
 DATE_FORMAT(DATE_SUB(`completeDateTime`, INTERVAL (DAYOFWEEK(`completeDateTime`)-8) DAY), '%Y/%m/%d') as end, 
 DATE_FORMAT(`completeDateTime`, '%Y%u') AS `date`, COUNT(distinct memberID) 
 FROM tbl_benefitPayment
 WHERE paymentType like 'normal' 
  and state LIKE 'complete'
  AND completeDateTime >= "2020-08-10 00:00:00"
  AND completeDateTime < "2020-08-14 00:00:00" 
 GROUP BY date

2. 월간 머플 결제자
select  month(b.completeDateTime) as 월,
 sum(a.price) as 결제금액,
 b.state, count(distinct a.memberRef) as 결제자수
from tbl_pg_payment a
left outer join tbl_benefitPayment b on a.giftCode = b.code
where
a.state = 1
and b.completeDateTime >= "2020-08-01 00:00:00"
AND b.completeDateTime < "2020-08-14 00:00:00"
group by b.state, month(b.completeDateTime)
order by month(b.completeDateTime)


SELECT recommendee AS oid, (

SELECT phone
FROM tbl_member
WHERE recommendee = oid
) AS phone, level, channel, registDateTime
FROM `tbl_vip`
WHERE DATE( registDateTime ) = '2020-07-31'