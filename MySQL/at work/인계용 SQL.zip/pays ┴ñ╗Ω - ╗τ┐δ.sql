# 프랜차이즈 월 사용내역
# producerRef
#       pays = 1
#       smartcon = 2
-- SELECT a.oid, a.shopName, a.memberRef, a.memberName, a.barCode, a.orderPrice, a.state, a.useDateTime AS 사용일
-- FROM tbl_order a
-- left outer join tbl_benefitPayment b on a.barCode = b.code
-- WHERE
--     a.barcode IS NOT NULL
--     AND a.consummerRef IN (SELECT c.oid
--             FROM tbl_giftConsummer c
--             WHERE
--                 c.producerRef = 1
--         )
--     and b.state  like 'complete'
--     and b.paymentType like 'normal'
--     AND a.useDateTime >= "2020-09-01 00:00:00"
--     AND a.useDateTime < "2020-10-01 00:00:00"

-- union

-- SELECT a.oid, a.shopName, a.memberRef, a.memberName, a.barCode, a.orderPrice, a.state, a.useDateTime AS 사용일
-- FROM tbl_order a
-- WHERE
--     a.barcode IS NOT NULL
--     AND a.consummerRef IN (SELECT c.oid
--             FROM tbl_giftConsummer c
--             WHERE
--                 c.producerRef = 1
--         )
--     and a.barcode not in (select code from tbl_benefitPayment where a.barcode = code)
--     AND a.useDateTime >= "2020-09-01 00:00:00"
--     AND a.useDateTime < "2020-10-01 00:00:00"


date_format(a.createTime, '%Y-%m') >= '2020-10' 


#       KTMhows = 4 6= 즐
 8 M12


SELECT 
case 
    when a.state = 3 thEn '사용완료'
    when a.state = 3 AND b.cancelState = 1 thEn '사용완료(상품권취소됨)'
    when a.state = 12 thEn '사용취소'
    when a.state = 12 AND b.cancelState = 0 thEn '사용취소요청(취소불가)'
    ELSE  '유저요청 취소'
END as '상태'
,a.originPrice, a.salePrice,a.payPrice,b.*, (select name from tbl_giftConsummer d where c.consummerRef=d.oid) as 이름
FROM tbl_payMenuHistory a, tbl_GiftMenuEvent b, tbl_giftMenu c
where a.barcode = b.barcodeNum
and b.MenuRef = c.oid
and c.producerRef = 6
and a.createTime >= '2020-11-01 00:00:00'
and a.createTime < '2020-12-01 00:00:00' 
order by a.createTime asc
;



# 본죽 대사 자료용 

select 
oid,
case when consummerRef = 86 then '본죽'
     when consummerRef = 87 then '본도시락'
     else '본죽&비빔밥' 
     end as 상호명, 
barCode, 
case when state = 2 then 'complete'
     else 'cancel'
     end as state,
orderPrice, 
pointPrice, 
payPrice, 
round((payPrice * 1.25),0) as originPrice, 
useDateTime, 
(
    select distinct shopCode 
    from tbl_paysUseInfo
    where giftCode = b.barCode
) as shopCode
from tbl_order b
where barCode in (
    select code 
    from tbl_payCodeGenerate
    where consummerRef IN (86,87,92)
        and paymentType IN (1)
        and date_format(modifyTime, '%Y-%m') >= '2020-11' 
        )
    and useDateTime >= '2020-11-01 00:00:00' 
    and useDateTime < '2020-12-01 00:00:00';

#스마트콘 2 #페이즈 1

select 
b.oid,
shopName,
barCode, 
b.state, ifnull(a.state,'머지머니총액권') as 베네핏상태, ifnull(a.paymentType,'머지머니총액권') as 금액구분,
orderPrice, 
pointPrice, 
payPrice, 
round((payPrice * 1.25),0) as originPrice, 
useDateTime
from tbl_order b
left outer join tbl_benefitPayment a on a.code = b.barCode
where barCode in (
    select code 
    from tbl_payCodeGenerate
    where producerRef = 7
        and state IN (2)
        and modifyTime >= '2020-11-01 00:00:00'
        and modifyTime < '2020-12-01 00:00:00' 
        )
    and useDateTime >= '2020-11-01 00:00:00' 
    and useDateTime < '2020-12-01 00:00:00';



select 
b.oid,
shopName,
barCode, 
b.state, 
ifnull(a.state,'머지머니총액권') as 베네핏상태, 
ifnull(a.paymentType,'머지머니총액권') as 금액구분,
orderPrice, 
pointPrice, 
payPrice, 
round((payPrice * 1.25),0) as originPrice, 
useDateTime
from tbl_order b
left outer join tbl_benefitPayment a on a.code = b.barCode
where barCode in (
    select code 
    from tbl_payCodeGenerate
    where producerRef = 1
        and state IN (1,2)
        and modifyTime >= '2020-11-01 00:00:00'
        and modifyTime < '2020-12-01 00:00:00' 
        )
    and useDateTime >= '2020-11-01 00:00:00' 
    and useDateTime < '2020-12-01 00:00:00';



select 
shopName,barCode, state, orderPrice, pointPrice, payPrice, useDateTime
from tbl_order
where consummerRef = 176
and state IN (2,5)
and useDateTime >= '2020-11-01 00:00:00' 
and useDateTime < '2020-12-01 00:00:00'

#######################################################################################################################################

SELECT oid, shopName, memberRef, barCode, orderPrice, (select costPrice from tbl_benefitPayment b where a.barcode = b.code) as 할인전원가, state, useDateTime AS 사용일
FROM tbl_order a
WHERE
    barcode IS NOT NULL
    AND consummerRef IN (SELECT oid
            FROM tbl_giftConsummer
            WHERE
                producerRef = 2
        )
    AND useDateTime >= "2020-06-01 00:00:00"
    AND useDateTime < "2020-07-01 00:00:00"


-- barcode 맞추고 금액은 



#결제금액 바코드 결제일시 6월정산 (결제 , 취소) 6.1~30 ktmhows만 
select wholesalePrice as  결제금액
 ,barcode as 바코드
 ,createTime as 결제일시
    ,(case when state = 3 then '사용'
  when state > 3 then '취소'
        else '예외'
   end) as 결제상태
 from tbl_payMenuHistory
 where producerRef = 4    #KTMhows   #tbl_giftProducer oid 참조
 and createTime >='2020-06-01'
    and createTime <'2020-07-01'
    order by createTime;






 show databases;
use settlement;
show tables;

desc 10consa;
desc 10smartcon;
#스마트콘에는 있고 우리한테는 없는 애들
select distinct barcode from oct_pays where barcode not in (select barCode from oct_pays_merge);
#우리한테 있는데 스마트콘에는 없는 애들
select barCode from oct_pays_merge where barcode not in (select barcode from oct_pays);