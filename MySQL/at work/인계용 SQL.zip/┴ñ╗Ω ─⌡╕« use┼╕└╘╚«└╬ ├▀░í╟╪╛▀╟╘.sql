#일반 테이블
select t3.*
,(t3.mergeCharge - t3.mergeVAT) as mergesupply
from(
select t2.*
,(t2.payPriceSettlement + t2.pointPriceSettlement) as usePointSettlement
,(t2.mergeCharge / 11) as mergeVAT

from(
select t1.*
,(t1.pgCharge + t1.payPriceCharge + t1.pointPriceCharge) as mergeCharge
,(t1.payPrice - t1.payPriceCharge - t1.pgCharge) as payPriceSettlement
,(t1.pointPrice - t1.pointPriceCharge) as pointPriceSettlement
from(
(select
a.oid as useRef
,a.shopRef
,a.shopName
,a.shopRate
,a.pgRate
,a.consummerRef
,a.memberRef
,b.name as memberName
,a.companyRef
#,c.companyName
,(select companyName from tbl_company as com where a.companyRef = com.oid) as companyName
,b.departRef
#,d.name as departName
,(select name from tbl_comDepart as depart where b.departRef = depart.oid) as departName
,a.menuName
,a.menuPrice
,a.useCount
,a.orderPrice
,(a.payPrice + a.pointPrice) as usePoint
,a.companyPoints
,a.payPrice
,(a.buyPoints + a.tampingPoints + a.accPoints) as pointPrice
,a.buyPoints
,a.tampingPoints
,a.accPoints
,a.pgCharge
,(a.pointPrice * (a.shopRate /1000)) as pointPriceCharge
,(a.payPrice * (a.shopRate / 1000)) as payPriceCharge
,(a.payPrice * a.memberRate / 1000) as accumulatePoint
,a.useType
,DATE(a.useDateTime) as useDateTime
,DATE(a.settlementDateTime) as settlementDateTime
#,(a.pgCharge + payPriceCharge + pointPriceCharge) as mergeCharge
from tbl_use a
inner join tbl_member b
on a.memberRef = b.oid
where a.settlementState = 2
        AND a.useDateTime >= "2018-12-16 00:00:00"
        AND a.useDateTime < "2019-01-01 00:00:00"
        AND a.payPrice + a.pointPrice > 0
        AND useType IN (2,4)
) as t1)) as t2) as t3;



# 기업
select
a.oid
,a.payMenuRef
,a.payShopRef
,a.paymentRef
,a.shopRef
,a.shopName
,a.shopRate
,a.pgRate
,a.consummerRef
,a.memberRate
,a.memberRef
,b.name as memberName
,a.companyRef
,(select companyName from tbl_company as com where a.companyRef = com.oid) as companyName
,b.departRef
,(select name from tbl_comDepart as depart where b.departRef = depart.oid) as departName
,a.menuName
,a.menuPrice
,a.useCount
,a.orderPrice
,a.pointPrice
,a.payPrice
,a.companyPoints
,round((a.companyPoints * (a.shopRate / 1000)),0) as mergeCompCharge
,round((a.companyPoints - (a.companyPoints * (a.shopRate / 1000))),0) as compSettlement
,round(((a.companyPoints * (a.shopRate / 1000)) / 11),0) as mergeCompVAT
,round(((a.companyPoints * (a.shopRate / 1000)) - ((a.companyPoints * (a.shopRate / 1000)) / 11)),0) as mergeCompsupply
,a.useDateTime as useDateTime
,a.settlementDateTime as settlementDateTime
,a.useType
,a.orderRef
#,(a.pgCharge + payPriceCharge + pointPriceCharge) as mergeCharge
from tbl_use a
inner join tbl_member b
on a.memberRef = b.oid
where 
        a.useDateTime >= "2018-12-01 00:00:00"
        AND a.useDateTime < "2019-01-01 00:00:00"
        AND useType IN (2,4)
        AND a.settlementState = 2
        AND a.companyPoints > 0
        AND a.shopRef = 1282;

SELECT * FROM tbl_shop
where shopName like '%cj%';

#가입일, 이름, 핸드폰번호
select name, phone, creDateTime from tbl_member
where osType = 2
AND state = 1;

select * from tbl_member
where name = '박정손';


# 전체 테이블
select
a.oid
,a.shopRef
,a.shopName
,a.shopRate
,a.pgRate
,a.memberRate
,a.memberRef
,b.name as memberName
,a.companyRef
,(select companyName from tbl_company as com where a.companyRef = com.oid) as companyName
,b.departRef
,(select name from tbl_comDepart as depart where b.departRef = depart.oid) as departName
,a.menuName
,a.menuPrice
,a.useCount
,a.orderPrice
,a.companyPoints
,(a.payPrice + a.pointPrice) as usePoint
,a.payPrice
,a.pointPrice
,a.buyPoints
,a.tampingPoints
,a.accPoints
,round(a.companyPoints * (a.shopRate / 1000),0) as mergeCompCharge
,round((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )),0) as mergeCharge
,round(a.payPrice * (a.pgRate / 1000),0) as pgCharge
,round(a.payPrice * (a.shopRate / 1000),0) as payPriceCharge
,round(a.pointPrice * (a.shopRate / 1000),0) as pointPriceCharge
,round(a.companyPoints * (a.shopRate / 1000) + (a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )),0) as totalMergeCharge
,round(a.companyPoints - (a.companyPoints * (a.shopRate / 1000)),0) as compSettlement
,round((a.payPrice - (a.payPrice * (a.shopRate / 1000)) - (a.payPrice * (a.pgRate / 1000))) + (a.pointPrice - (a.pointPrice * (a.shopRate / 1000))),0) as usePointSettlement
,round(a.payPrice - (a.payPrice * (a.shopRate / 1000)) - (a.payPrice * (a.pgRate / 1000)),0) as payPriceSettlement
,round(a.pointPrice - (a.pointPrice * (a.shopRate / 1000)),0) as pointPriceSettlement
,round(((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) -
        ((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) / 11)),0) as mergesupply
,round(((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) / 11),0) as mergeVAT
,round((a.companyPoints * (a.shopRate / 1000)) - ((a.companyPoints * (a.shopRate / 1000)/11)),0) as mergeCompsupply
,round((a.companyPoints * (a.shopRate / 1000)/11),0) as mergeCompVAT
,round((payPrice * (memberRate)/1000),0) as accumulatePoint
,DATE(a.useDateTime) as useDateTime
,DATE(a.settlementDateTime) as settlementDateTime
from tbl_use a
inner join tbl_member b
on a.memberRef = b.oid

#where DATE(a.settlementDateTime) = "2018-11-22"
        AND a.settlementDateTime >= "2018-12-01 00:00:00"
        AND a.settlementDateTime < "2019-01-01 00:00:00"
        AND a.settlementState = 2;

select * from tbl_member
where name = '박정아';


select * from tbl_member
where id in( 'wogus0612a@gmail.com','wndksdms15@gmail.com');

#091995keb@naver.com, 6692
select * from tbl_member
where name = '김은비';

select * from tbl_pointsHistory
where memberRef = 6692;

select * from tbl_shop;

select * from tbl_member
where name = '방주안';

#5488
select * from tbl_member
where name = '박현철';

select * from tbl_payment
where memberRef = 5488;

select * from tbl_use
where memberRef = 5488;

select * from tbl_shop
where oid = 3411;


#1.0.2

select * from tbl_shopAppVersion;
