# 프랜차이즈 월 사용내역
# producerRef
#       pays = 1
#       smartcon = 2
SELECT a.oid, a.shopName, a.memberRef, a.memberName, a.barCode, a.orderPrice, a.state, a.useDateTime AS 사용일
FROM tbl_order a
left outer join tbl_benefitPayment b on a.barCode = b.code
WHERE
    a.barcode IS NOT NULL
    AND a.consummerRef IN (SELECT c.oid
            FROM tbl_giftConsummer c
            WHERE
                c.producerRef = 2
        )
    and b.state  like 'complete'
    AND a.useDateTime >= "2020-08-01 00:00:00"
    AND a.useDateTime < "2020-09-01 00:00:00"

union

SELECT a.oid, a.shopName, a.memberRef, a.memberName, a.barCode, a.orderPrice, a.state, a.useDateTime AS 사용일
FROM tbl_order a
WHERE
    a.barcode IS NOT NULL
    AND a.consummerRef IN (SELECT c.oid
            FROM tbl_giftConsummer c
            WHERE
                c.producerRef = 2
        )
    and a.barcode not in (select code from tbl_benefitPayment where a.barcode = code)
    AND a.useDateTime >= "2020-08-01 00:00:00"
    AND a.useDateTime < "2020-09-01 00:00:00"
