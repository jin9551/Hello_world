select  t.회원번호, t.성함, t.전화번호, t.할인받은금액
from (select b.oid as 회원번호, a.name as 성함, a.phone as 전화번호, b.currTotalSalePrice as 할인받은금액
from tbl_member a
left outer join tbl_benefitUser b on b.oid=a.oid
where a.oid = b.oid) t
where t.할인받은금액 = 0


select a.oid as 회원번호, b.name as 성함, b.phone as 전화번호, a.membershipState,  a.currTotalSalePrice as 할인받은금액
from tbl_benefitUser a
left outer join tbl_member b on b.oid=a.oid
where a.currTotalSalePrice = 0


select memberID, b.name, b.phone, sum(paycoPrice) as 사용금액
from tbl_benefitPayment a
left outer join tbl_member b on b.oid=a.memberID
where a.state like 'complete'
group by memberID


select a.oid, a.createTime, a.currTotalSalePrice, c.channel, f.state as 페이코, ifnull(sum(b.paycoPrice), 0) as 사용취소금액
from tbl_benefitUser a 
left outer join tbl_benefitPayment b on a.oid = b.memberID
left outer join tbl_vip c on a.oid = c.recommendee
LEFT OUTER JOIN tbl_pg_payco f on a.oid = f.memberRef
where a.createTime >= '2020-06-29 00:00:00' and a.createTime < '2020-07-04 00:00:00'

group by a.oid


