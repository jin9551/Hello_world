  select t2.oid
    ,t2.orderCount
    ,t2.orderMenuCount
    ,t2.companyRef
    ,ifnull(t2.companyName,'일반회원') as companyName
    ,t2.shopRef
    ,t2.shopName
    ,t2.menuName
    ,t2.orderPrice
    ,t2.payPrice
    ,t2.companyPoints
    ,t2.couponPrice
    ,t2.pointPrice
    ,t2.approveDateTime
    , date_format(t2.approveDateTime, '%Y-%m-%d %H:%i:%s')
    ,t2.time
    from(SELECT DISTINCT
	a.oid
	, b.orderCount
	,(SELECT count(orderRef) FROM tbl_orderRequestMenu where a.oid = orderRef) AS orderMenuCount
	, a.companyRef
	,(SELECT ifnull(companyName,'d') FROM tbl_company where a.companyRef = oid) AS companyName
	, a.shopRef
	, a.shopName
	, group_concat(c.name separator "||") AS menuName
	, a.orderPrice
	, a.payPrice
	, a.companyPoints
	, a.couponPrice 
	, a.pointPrice
	, a.approveDateTime
	,date_format(a.approveDateTime,"%H") AS time
	FROM tbl_order a
	INNER JOIN tbl_orderRequestMenu b
	on a.oid = b.orderRef
	inner join tbl_payMenu c
	on a.shopRef = c.shopRef
	and c.oid = b.payMenuRef
	where a.state = 2
	and a.shopRef = 1278
	and DATE(a.approveDateTime) = '2018-11-27'
	group by a.oid
	order by time desc, approveDateTime desc)t2