# 주문 사용 승인 금액 추출
SELECT oid, memberRef, orderPrice, approveDateTime
FROM  tbl_order
WHERE state =2
AND useDateTime >  "2019-04-01 00:00:00"
ORDER BY oid ASC

# 사용 승인 금액 추출
SELECT orderRef, SUM(orderPrice)
FROM  tbl_use
WHERE orderRef IN (
    SELECT oid
    FROM tbl_order 
    WHERE state =2
    AND useDateTime >  "2019-04-01 00:00:00"
)
GROUP BY orderRef
ORDER BY orderRef ASC

# 20190123
# 3908,3396,3528,3447,3538

# 20190124
# orderRef 50609 51212 51217 51225

# 20190130
# orderRef 51338, 51476, 51678, 51841, 53126, 53257, 53314

# 희망 - 이 경우는 20190129 저녁 이후로는 안나올 것이라 기대
# 20190201 이슈 안나옴.

# 20190212 5건 발생
# orderRef 55653, 57605, 57652, 58135, 58169
# payShopRef 70172, 72258, 72318, 72902, 72868

# 20190221 1건 발생
# orderRef 74399

# 20190318 이중 사용 없음

# 20190423 - 7건 발생
# 161534, 165421, 172806, 177851, 178071, 178122, 189060

SELECT payMenuRef, orderRef, COUNT(oid) AS useCount
FROM tbl_use
WHERE payMenuRef > 0
    AND orderRef > 0
    AND useDateTime >  "2019-08-01 00:00:00"
GROUP BY payMenuRef, orderRef
ORDER BY COUNT(oid) DESC

# 20190430 - 1건 발생
# orderRef 216720
# 20190516 - 4건 발생
# orderRef 222822, 226185, 226415, 224692
# 20190527 - 6건 발생
# orderRef 229356, 230163, 230279, 230828, 231772, 230978
# 20190603 - 3건 발생
# orderRef 238811, 240627, 238361
# 20190612 - 1건 발생
# orderRef 241265
#20190617 - 4건 발생
# orderRef 249346, 249319, 248539, 249277
# 20190701 - 4건 발생
# orderRef 260535, 260679, 260971, 253463
# 20190801  - 7건 발생
# orderRef 307753, 319594, 356388, 310954, 305962, 330002, 339035
# 20190902 - 6건 발생
# orderRef 407221, 396318, 401575, 427721, 402578, 389169