To. 카레맨 or 째잌으 


날짜만 변경해서 그대로 쓰세요.


"--파일명.xlsx--"이라고 적혀있는 이름대로 저장하시면 되고
각 파일에 들어가는 데이터들은 쿼리문 위에 적힌 "#시트 이름"대로 저장하면 되요.

쿼리문은 보지마요 눈 버려요. 엄청 옛날에 쓴거라 q(^ㅠ^)p

이거만 루틴이고 추가로 뭐 물어보면 모른다고 하세요. ^-^)b

위 3개 파일은 M팀 미성님한테 보내주세요. 

---------------------------------------------- 콘사콘사.xlsx-----------------------------------------------------------------
#프랜 
SELECT YEAR( useDateTime ) AS 사용년도, DATE( useDateTime ) AS 일별, consummerRef, shopName, SUM( orderPrice ) AS 사용금액
FROM tbl_order
WHERE consummerRef >0
    AND state IN (2,5)
    AND useDateTime >= "2020-05-26 00:00:00" --전날  예) 어제가 26일
    and useDateTime < "2020-05-27 00:00:00"  --당일      오늘이 27일 
GROUP BY YEAR( useDateTime ) , DATE( useDateTime ) , consummerRef

#프랜취소
SELECT YEAR( useDateTime ) AS 사용년도, MONTH(useDateTime) AS 월, consummerRef, shopName, SUM( orderPrice ) AS 취소금액
FROM tbl_order
WHERE consummerRef >0
    AND state IN (5)
   AND useDateTime >= "2020-05-01 00:00:00"
    AND useDateTime < "2020-05-27 00:00:00"    -- 얘는 요거만 오늘 날짜로
GROUP BY YEAR( useDateTime ), MONTH(useDateTime), consummerRef

#일반
SELECT YEAR( useDateTime ) AS 사용년도, DATE( useDateTime ) AS 일별, SUM( orderPrice ) AS 사용금액
FROM tbl_order
WHERE consummerRef = 0
    AND state IN (2,5)
     AND useDateTime >= "2020-05-01 00:00:00"
    AND useDateTime < "2020-05-27 00:00:00"     -- 얘는 요거만 오늘 날짜로
GROUP BY YEAR( useDateTime ) , DATE( useDateTime ) 

#일반취소
SELECT MONTH( creDateTime ) AS 월, SUM( orderPrice ) AS 누적취소금액
FROM `tbl_payShop`
WHERE `consummerRef` =0
AND `settlementState` =5
AND `useState` =4
AND `creDateTime` >= '2020-05-01 00:00:00'
AND `creDateTime` < '2020-05-27 00:00:00'   -- 얘는 요거만 오늘 날짜로

----------------------------------------------------------------------------------------------------------------------------


---------------------------------------------- 포인트관리.xlsx---------------------------------------------------------------


#포인트관리
SELECT YEAR( useDateTime ) AS 사용년도, MONTH( useDateTime ) AS 사용월, SUM( accPoints ) AS 적립포인트, SUM( buyPoints ) AS 구매포인트, SUM( tampingPoints ) AS 탬핑포인트
FROM tbl_use
WHERE orderRef
IN (
SELECT oid
FROM tbl_order
WHERE state =5
)
AND useDateTime >= "2017-01-01 00:00:00"
AND useDateTime < "2020-05-27 00:00:00"  -- 얘는 요거만 오늘 날짜로
GROUP BY YEAR( useDateTime ) , MONTH( useDateTime )


#포인트일반
SELECT YEAR( useDateTime ) AS 사용년도, MONTH( useDateTime ) AS 사용월, SUM( accPoints ) AS 적립포인트, SUM( buyPoints ) AS 구매포인트, SUM( tampingPoints ) AS 탬핑포인트
FROM tbl_use
WHERE useType = 5 #일반매장
AND useDateTime >= "2017-01-01 00:00:00"
AND useDateTime < "2020-05-27 00:00:00" -- 얘도 요거만 오늘 날짜로
GROUP BY YEAR( useDateTime ) , MONTH( useDateTime )

#절대값
select YEAR( useDateTime ) AS 사용년도, date( useDateTime ) AS 사용일, SUM( accPoints ) AS 적립포인트, SUM( buyPoints ) AS 구매포인트, SUM( tampingPoints ) AS 탬핑포인트
from tbl_use
where 
 useDateTime >= "2020-05-26 00:00:00"
AND useDateTime < "2020-05-27 00:00:00"
GROUP BY YEAR( useDateTime ) , date( useDateTime )


# 만료
SELECT *
FROM `tbl_pointsHistory`
WHERE `type` =3
AND totalPoints = 0
AND  creDateTime >= "2020-05-26 00:00:00"
AND  creDateTime < "2020-05-27 00:00:00"


#회수
SELECT *
FROM `tbl_pointsHistory`
WHERE `reason` LIKE '%회수%'
AND totalPoints = 0
AND  creDateTime >= "2020-05-26 00:00:00"
AND  creDateTime < "2020-05-27 00:00:00"




---------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------- 결제.xlsx---------------------------------------------------------------

#결제횟수
SELECT DATE(useDateTime) as 일, COUNT(oid) 결제횟수 FROM `tbl_order` WHERE useDateTime >= '2020-05-26 00:00:00' AND useDateTime < '2020-05-27 00:00:00'
group by  DATE(useDateTime)

#결제자수
SELECT DATE(useDateTime) as 일, COUNT(distinct memberRef) as 결제자수 FROM `tbl_order` WHERE useDateTime >= '2020-05-26 00:00:00' AND useDateTime < '2020-05-27 00:00:00'
group by  DATE(useDateTime)

#사용금액(결제+취소)
SELECT DATE(useDateTime) as 일, SUM(orderPrice) as 사용금액 FROM `tbl_order` WHERE useDateTime >= '2020-05-26 00:00:00' AND useDateTime < '2020-05-27 00:00:00'
group by  DATE(useDateTime)

---------------------------------------------------------------------------------------------------------------------------


요거는 송훈님한테 보내주세요

--------------------------------------------------- GS25 도시락 이벤트.xlsx--------------------------------------------------
#GS25 도시락 이벤트
select a.oid,promotionRef, groupRef, code, a.points,b.creDateTime as 가입일, registDateTime as 등록일, memberRef, membername, memberPhone,
  (CASE
        WHEN b.creDateTime >= '2020-04-03' THEN 'Y'
        WHEN b.creDateTime < '2020-04-03' THEN 'N'
END) AS 신규여부, count(a.oid) as 등록횟수
from tbl_pointCode a
left outer join tbl_member b on a.memberRef = b.oid
where 
promotionRef = 303
and a.state =3
and registDateTime between '2020-05-26 00:00:00' and '2020-05-27 00:00:00'
group by memberRef


#바우처 구분
select date(registDateTime), promotionRef, groupRef, points, name, count(oid)
from tbl_pointCode
where 
promotionRef = 303
and state =3
and registDateTime between '2020-05-26 00:00:00' and '2020-05-27 00:00:00'
group by date(registDateTime), promotionRef, groupRef

---------------------------------------------------------------------------------------------------------------------------