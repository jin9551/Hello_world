
# 김주은/마케팅 팀 요청 처리용!
# 포인트 발행 및 사용량 정보 월별
# 포인트 발행
SELECT YEAR(creDateTime) AS 사용년도, MONTH(creDateTime) AS 사용월,
    SUM(buyPoints) AS 구매포인트발행, SUM(accPoints)  AS 적립포인트발행, SUM(tampingPoints) AS 지급포인트발행
FROM tbl_pointsHistory
WHERE
    totalPoints = 0
    AND type = 1
    AND reason NOT LIKE "%취소%"
    AND creDateTime >= "2017-01-01 00:00:00"
GROUP BY
    YEAR(creDateTime), MONTH(creDateTime)

# 일별 발행
SELECT YEAR(creDateTime) AS 발행년도, MONTH(creDateTime) AS 발행월,
    DAY(creDateTime) AS 발행일,
    SUM(buyPoints) AS 구매포인트발행, SUM(accPoints)  AS 적립포인트발행, SUM(tampingPoints) AS 지급포인트발행
FROM tbl_pointsHistory
WHERE
    totalPoints = 0
    AND type = 1
    AND reason NOT LIKE "%취소%"
    AND creDateTime >= "2019-03-01 00:00:00"
GROUP BY
    YEAR(creDateTime), MONTH(creDateTime), DAY(creDateTime)

# 포인트 잔액
SELECT YEAR(creDateTime) AS 사용년도, MONTH(creDateTime) AS 사용월,
    SUM(remainPoints)  AS 구매포인트잔액
FROM tbl_pointsHistory
WHERE
    buyPoints > 0
    AND type = 1
    AND reason NOT LIKE "%취소%"
GROUP BY

    YEAR(creDateTime), MONTH(creDateTime)

# 포인트 구분
SELECT YEAR(useDateTime) AS 사용년도, MONTH(useDateTime) AS 사용월,
        SUM(orderPrice) AS 사용금액, SUM(pointPrice) AS 포인트합, SUM(accPoints) AS 적립포인트, SUM(buyPoints) AS 구매포인트, SUM(tampingPoints) AS 적립포인트,
        SUM(companyPoints) AS 기업포인트, SUM(payPrice) AS 결제금액
FROM tbl_use
WHERE orderRef IN (
    SELECT oid
    FROM tbl_order
    WHERE
        state = 2
        AND barCode IS NOT NULL
    )
GROUP BY
    YEAR(useDateTime), MONTH(useDateTime)

#만료예정 포인트

SELECT 
    SUM(orderPoints)  AS 만료예정포인트
FROM tbl_use
WHERE
    remainPoints > 0
    AND useType = 2

#박미성 
# 2019.08.26-2019.09.25 일별 결제자 수, 결제 횟수, 결제 금액
SELECT YEAR(useDateTime) AS 년도, DATE(useDateTime) AS 일, SUM(useCount) AS 결제횟수, COUNT(memberRef) AS 결제자수, SUM(orderPrice) AS 결제금액
FROM tbl_use
WHERE
    settlementState IN (2, 3)
    AND useType IN (2,3)
    AND useDateTime >= "2019-08-26 00:00:00"
    AND useDateTime < "2019-09-26 00:00:00"
GROUP BY DATE(useDateTime)


#신유경 한달 결제금액 15000원 이하 회원 정보 처리
SELECT a.memberRef,b.name, SUM(orderPrice) AS 결제금액
FROM tbl_use a
left outer join tbl_member b on a.memberRef = b.oid #tbl_use에는 회원 이름이 나오지 않는다. 회원 이름을 tbl_member에서 가져오자.
WHERE
    settlementState IN (2, 3)
    AND useType IN (2,3)
    AND useDateTime >= "2019-09-01 00:00:00"
    AND useDateTime < "2019-09-26 00:00:00"
GROUP BY a.memberRef 

#일별 결제 횟수

SELECT DATE(useDateTime), a.memberRef,b.name, COUNT(memberRef)
FROM tbl_use a
left outer join tbl_member b on a.memberRef = b.oid #tbl_use에는 회원 이름이 나오지 않는다. 회원 이름을 tbl_member에서 가져오자.
WHERE
    settlementState IN (2, 3)
    AND useType IN (2,3)
    AND useDateTime >= "2019-09-01 00:00:00"
    AND useDateTime < "2019-09-26 00:00:00"
GROUP BY DATE(useDateTime), a.memberRef 

#이은지 시간대별 사용자 - 수정 필요할거임
SELECT YEAR(useDateTime) AS 사용년도, 
 DATE(useDateTime) AS 사용일, HOUR(useDateTime) AS 사용시간, COUNT(oid)
FROM tbl_order
WHERE  
    barCode is NOT NULL
    AND state = 2
    AND useDateTime >= "2019-01-01 00:00:00" 
GROUP BY YEAR(useDateTime),  DATE(useDateTime),
 HOUR(useDateTime)

#시간대별 프랜차이즈 이용자 + 구매가격
 SELECT YEAR(useDateTime) AS Year, DATE(useDateTime) AS Date, HOUR(useDateTime) AS 시간, memberRef, memberName, orderPrice AS 결제금액 
FROM tbl_order 
WHERE
    barcode IS NOT NULL
    AND state = 2
    AND useDateTime >= "2019-01-01 00:00:00"
    AND useDateTime < "2019-09-26 00:00:00"
ORDER BY useDateTime asc


#####################남녀 회원 수 및 생년 구분. 1은 남자 2는 여자
SELECT DATE(useDateTime) AS 결제일,YEAR(birthday) AS 연령, b.memberRef, b.memberName, b.gender
FROM tbl_order a
left outer join tbl_member b on a.memberRef = b.oid
WHERE 
 a.state = 2
  AND useDateTime >= "2019-09-15 00:00:00"
    AND useDateTime < "2019-09-26 00:00:00"
ORDER BY DATE(useDateTime)



#카페베네 시간대별 사용자 + 금액 + 할인금액
###################################
SELECT HOUR(useDateTime), SUM(orderPrice) AS 결제금액, SUM(discountPrice) AS 할인금액, COUNT(memberRef)
FROM tbl_use a
left outer join tbl_member b on a.memberRef = b.oid #tbl_use에는 회원 이름이 나오지 않는다. 회원 이름을 tbl_member에서 가져오자.
WHERE
    consummerRef = 23
    AND settlementState IN (2, 3)
    AND useType IN (2,3)
    AND useDateTime >= "2019-10-03 00:00:00"
    AND useDateTime < "2019-10-04 00:00:00"
GROUP BY HOUR(useDateTime) 





#프렌차이즈 일별 매출
SELECT DATE(useDateTime) AS 사용일시, shopName, consummerRef, SUM(orderPrice) AS 사용금액, COUNT(oid) AS 사용횟수
FROM tbl_use
WHERE
    consummerRef > 0
    AND useType IN (2, 3)
    AND useDateTime >= "2017-07-19 00:00:00"
    AND useDateTime < "2019-07-25 00:00:00"
GROUP BY DATE(useDateTime), consummerRef
ORDER BY DATE(useDateTime)


#일반매장 일별매출.
SELECT DATE(useDateTime) AS 사용일시, 
        consummerRef, shopName, SUM( orderPrice ) AS 사용금액
FROM tbl_order
WHERE shopType = 1
    AND state =2
    AND useDateTime >= "2019-05-01 00:00:00"
GROUP BY DATE(useDateTime), consummerRef




#일반 매장 조사
#김대용
#use 자료 주기
select
a.shopName
,a.menuPrice
,a.orderPrice
,a.companyPoints
,(a.payPrice + a.pointPrice) as usePoint
,a.pointPrice
,a.buyPoints
,round((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )),0) as mergeCharge
,round(a.pointPrice * (a.shopRate / 1000),0) as pointPriceCharge
,round(a.companyPoints * (a.shopRate / 1000) + (a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )),0) as totalMergeCharge
,round((a.payPrice - (a.payPrice * (a.shopRate / 1000)) - (a.payPrice * (a.pgRate / 1000))) + (a.pointPrice - (a.pointPrice * (a.shopRate / 1000))),0) as usePointSettlement
,round(a.payPrice - (a.payPrice * (a.shopRate / 1000)) - (a.payPrice * (a.pgRate / 1000)),0) as payPriceSettlement
,round(a.pointPrice - (a.pointPrice * (a.shopRate / 1000)),0) as pointPriceSettlement
,round(((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) -
        ((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) / 11)),0) as mergesupply
,round(((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) / 11),0) as mergeVAT
,a.useDateTime as useDateTime
,c.barcode
from tbl_use a
left outer join tbl_member b on a.memberRef = b.oid
left outer join tbl_order c on c.oid = a.orderRef
WHERE
        a.settlementState IN (2,3)
        AND useType IN (2, 3)
        AND a.useDateTime >= "2019-08-20 00:00:00"
        AND a.useDateTime < "2019-09-01 00:00:00"
ORDER BY a.useDateTime;