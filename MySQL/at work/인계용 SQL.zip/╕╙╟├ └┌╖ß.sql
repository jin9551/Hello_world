SELECT a.oid, a.phone,
 a.creDateTime AS 가입일,
 b.registDateTime AS VIP등록일,
  a.name, b.channel, 
  c.membershipState, 
  c.subscriptionState, 
  a.state, 
  (select count(e.oid) from tbl_vipRewardHistory e where e.recommender = a.oid and e.type = 2)  AS 초청자AU,
  (select COUNT(f.recommender) from tbl_vip f where f.recommender = a.oid and f.recommendee is not null) AS 사용코드개수, 
  (select COUNT( d.oid ) from tbl_benefitPayment d where d.memberID = a.oid  and d.state LIKE 'complete' AND d.completeDateTime BETWEEN '2020-06-30 00:00:00' AND '2020-06-30 23:59:59') as 사용횟수, 
  (select SUM( d.paycoPrice ) from tbl_benefitPayment d where  d.memberID = a.oid and d.state LIKE 'complete' AND d.completeDateTime BETWEEN '2020-06-30 00:00:00' AND '2020-06-30 23:59:59') as 사용금액
FROM tbl_member a
LEFT OUTER JOIN tbl_vip b ON a.oid = b.recommendee
LEFT OUTER JOIN tbl_benefitUser c ON a.oid = c.oid
WHERE a.phone IN ()
group by a.oid