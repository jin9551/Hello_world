
# 회원 포인트 내역 - 조미나 (사용현황)
SELECT *,
    (SELECT name
     FROM tbl_member
     WHERE oid = a.memberRef
     ) AS name
FROM tbl_pointsHistory AS a
WHERE
     totalPoints = 0
    AND memberRef IN (
        SELECT oid
        FROM tbl_member
        WHERE
        oid IN (1,107,165,898,4074,80612,80615,98834)
#           id IN ("hkcan81@30agro.co.kr")
#            phone IN ("01088731982")
        )
ORDER BY memberRef, creDateTime


# 바코드 번호 확인용 -> 회원 결제 기록 확인용!

SELECT odr.oid, odr.memberRef, odr.memberName, mem.phone, odr.shopName, odr.barcode, odr.pointPrice, odr.pointPrice, odr.companyPoints,
    odr.couponPrice, odr.payPrice, odr.returnPoints,
    odr.state, odr.reason, approveDateTime AS 사용일시
FROM tbl_order AS odr
LEFT OUTER JOIN tbl_member AS mem ON mem.oid = odr.memberRef
WHERE
    memberRef = (SELECT oid
        FROM tbl_member
        WHERE
            id LIKE "hr.son@wonwoo.com"
#            phone LIKE ("010XXXXLLLL")
    )
ORDER BY odr.memberRef, odr.approveDateTime


# 8/28 이베이 GS프로모션 - 154/ 프로모션 조회 일별 쿠폰 확인 
SELECT oid, code,
    (SELECT groupName
        FROM tbl_pointCodeGroup
        WHERE oid = pcode.groupRef
    ) AS 금액권명, points,
    registDateTime AS 등록일시
FROM tbl_pointCode AS pcode
WHERE
    promotionRef = 154
    AND state = 3
    AND registDateTime >= '2019-09-06 00:00:00' 
    AND registDateTime < '2019-09-09 00:00:00' 
ORDER BY registDateTime #쿠폰 등록 시간으로 정렬


#일반매장 일별매출
SELECT DATE(useDateTime) AS 사용일시, 
        consummerRef, shopName, SUM( orderPrice ) AS 사용금액
FROM tbl_order
WHERE shopType = 1
    AND state =2
    AND useDateTime >= "2019-05-01 00:00:00"
GROUP BY DATE(useDateTime), consummerRe



#2019 09 18 
#옥션,G마켓,G9 프로모션 핀 등록 현황.
# 12.04 추가 내용
#11.2 옥션 
#11.2 G마켓 
#12/4 옥션
#12/4 G마켓
#12/11 11번가

SELECT oid, promotionRef, code, (
SELECT groupName
FROM tbl_pointCodeGroup
WHERE oid = pcode.groupRef
) AS 금액권명, points, registDateTime AS 등록일시
FROM `tbl_pointCode` AS pcode
WHERE `promotionRef`
IN (222,223,240,241)
AND state =3
AND registDateTime >= '2019-12-10 00:00:00'
AND registDateTime < '2019-12-12 00:00:00' 

#포인트 조회
# 회원 포인트 내역 - 조미나 (사용현황)
SELECT *,
    (SELECT name
     FROM tbl_member
     WHERE oid = a.memberRef
     ) AS name
FROM tbl_pointsHistory AS a
WHERE
     totalPoints = 0
    AND memberRef IN (
        SELECT oid
        FROM tbl_member
        WHERE
    #       id IN ("w5eererere@naver.com")
            phone IN ("01032492362")
        )
ORDER BY memberRef, creDateTime


# 김대용
# 점포 구분
SELECT oid, id, shopName, 
    (CASE
        WHEN type = 1 THEN "로컬가맹점"
        WHEN type = 4 THEN "프랜차이즈"
    END) AS 점포종류,
    consummerName,
    shopPhone, postcode, address01, address02, longitude, latitude,
    ownerName, ownerPhone, ownerEmail,
    businessNumber, bankCode, accountNumber, accountHolder
FROM tbl_shop
WHERE
    state = 3

#최근 바코드
select *
from tbl_paysGiftCard
where memberRef = 82873
order by oid desc



select *
from tbl_paysGiftCard a
where memberRef = (select oid from tbl_member where phone in(01052639685))
and GfctNo not in (select barcode from tbl_order where GfctNo = barcode)
order by oid desc
limit 30;

select *
from tbl_paysGiftCard a
where memberRef = 327115
and GfctNo not in (select barcode from tbl_order where GfctNo = barcode)
order by oid desc
limit 30;

#사용하지 않은 바코드



######################################################################
GS25/CU
select a.oid,promotionRef, groupRef, code, a.points,b.creDateTime as 가입일, registDateTime as 등록일, memberRef, membername, memberPhone,

  (CASE
        WHEN b.creDateTime >= '2020-07-06' THEN 'Y'
        WHEN b.creDateTime < '2020-07-06' THEN 'N'
END) AS 신규여부, count(a.oid) as 등록횟수
from tbl_pointCode a
left outer join tbl_member b on a.memberRef = b.oid
where 
promotionRef = 373
and a.state =3
and registDateTime between '2020-07-06 00:00:00' and '2020-08-01 00:00:00'
group by memberRef

select date(registDateTime), promotionRef, groupRef, points, name, count(oid)
from tbl_pointCode
where 
promotionRef = 373
and state =3
and registDateTime between '2020-07-06 00:00:00' and '2020-08-01 00:00:00'
group by date(registDateTime), promotionRef, groupRef


SELECT promotionRef,memberRef, sum(points), (select name from tbl_promotion a where a.oid = promotionRef)as name, registDateTime as 등록일 
FROM `tbl_pointCode` 
WHERE memberRef in (select memberRef from tbl_pointCode where promotionRef = 373 and state =3)
and promotionRef != 373 and state =3 and registDateTime >= '2020-07-06 00:00:00'
group by promotionRef,memberRef

select memberRef, shopName, pointPrice as 사용금액, useDateTime
from tbl_order
where memberRef in  (select memberRef from tbl_pointCode where promotionRef = 373 and state =3) 
and useDateTime >= '2020-07-06'



####################################################################
select oid, shopName, consummerRef, memberRef, orderPrice as 사용금액, useDateTime as 사용시간, case when state = 2 then "결제완료" when state =5 then "결제취소" end as 결제상태
from tbl_order
where 
memberRef IN ()
and
useDateTime between '2020-04-03 00:00:00' and '2020-04-23 00:00:00'



SELECT oid, id, shopName, 
    (CASE
        WHEN state = 0 THEN "사용안함"
        WHEN state = 1 THEN "승인준비중"
        when state = 2 then "확인준비중"
        when state = 3 then "운영중"
        when state = 4 then "이용중지"
        when state = 5 then "계약해지"
        when state = 10 then "시험용점포"
    END) AS 점포상태, consummerName,  consummerRef,
    shopPhone, postcode, address01, address02,
    ownerName, ownerPhone, ownerEmail,
    businessNumber, bankCode, accountNumber, accountHolder
    
FROM tbl_shop
WHERE consummerRef in (0)



##########################################################################
-- 가정산
select
a.oid
,a.paymentRef
,a.shopRef
,a.shopName
,a.shopRate
,a.pgRate
,a.memberRate
,a.memberRef
,b.name as memberName
,a.companyRef
,(select companyName from tbl_company as com where a.companyRef = com.oid) as companyName
,b.departRef
,(select name from tbl_comDepart as depart where b.departRef = depart.oid) as departName
,a.menuName
,a.menuPrice
,a.useCount
,a.orderPrice
,a.companyPoints
,(a.payPrice + a.pointPrice) as usePoint
,a.payPrice
,a.pointPrice
,a.buyPoints
,a.tampingPoints
,a.accPoints
,round(a.companyPoints * (a.shopRate / 1000),0) as mergeCompCharge
,round((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )),0) as mergeCharge
,round(a.payPrice * (a.pgRate / 1000),0) as pgCharge
,round(a.payPrice * (a.shopRate / 1000),0) as payPriceCharge
,round(a.pointPrice * (a.shopRate / 1000),0) as pointPriceCharge
,round(a.companyPoints * (a.shopRate / 1000) + (a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )),0) as totalMergeCharge
,round(a.companyPoints - (a.companyPoints * (a.shopRate / 1000)),0) as compSettlement
,round((a.payPrice - (a.payPrice * (a.shopRate / 1000)) - (a.payPrice * (a.pgRate / 1000))) + (a.pointPrice - (a.pointPrice * (a.shopRate / 1000))),0) as usePointSettlement
,round(a.payPrice - (a.payPrice * (a.shopRate / 1000)) - (a.payPrice * (a.pgRate / 1000)),0) as payPriceSettlement
,round(a.pointPrice - (a.pointPrice * (a.shopRate / 1000)),0) as pointPriceSettlement
,round(((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) -
        ((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) / 11)),0) as mergesupply
,round(((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) / 11),0) as mergeVAT
,round((a.companyPoints * (a.shopRate / 1000)) - ((a.companyPoints * (a.shopRate / 1000)/11)),0) as mergeCompsupply
,round((a.companyPoints * (a.shopRate / 1000)/11),0) as mergeCompVAT
,round((a.payPrice * (memberRate)/1000),0) as accumulatePoint
,a.useDateTime as useDateTime
,a.orderRef
,c.barcode
from tbl_use a
left outer join tbl_member b on a.memberRef = b.oid
left outer join tbl_order c on c.oid = a.orderRef
WHERE
        a.shopRef IN (1044,6190,20908,21086,21680,31521,33276,33322,33190,33311)
        -- (20832,1277,1107,1302,33301)
        and a.settlementState IN (2,3)
        AND useType IN (2, 3)
        AND a.useDateTime >= "2020-12-01 00:00:00"
        AND a.useDateTime < "2020-12-16 00:00:00"
ORDER BY a.useDateTime;



SELECT oid
FROM `tbl_shop`
WHERE `shopName` LIKE '%샐러디%'
AND state =3


-- 안녕하세요~ 아래 자료 요청 드립니다! 2개 파일 나눠서 전달 부탁드립니다~

-- 1. 기존 가입고객 중 최근 3개월 F&B(편의점 제외) 평균 사용금액이 15만원 이상인 고객 
-- -> 요청내역: 고객명, 연락처, 계정ID, 결제금액, 브랜드 사용횟수

-- 2. 기존 가입고객 중  F&B(편의점 제외) 결제 횟수가 15건 이상인 고객-> 고객명, 연락처, 계정ID, 결제금액, 브랜드 사용횟수

SELECT memberRef, memberName, 
(select phone from tbl_member where memberRef = oid) as 전번,
(select points from tbl_member where memberRef = oid) as 잔여포인트, 
(select date(creDateTime) from tbl_member where memberRef = oid) as 가입일, 
(select id from tbl_member where memberRef = oid) as ID, round((SUM( pointPrice )/3),0) AS 평균사용금액, count(oid) as 결제횟수
FROM tbl_order
WHERE consummerRef not in (0,40,47)
    AND state IN (2,5)
    AND useDateTime between "2020-02-01 00:00:00" and "2020-04-30 23:59:59"
GROUP BY memberRef
having 평균사용금액 >= 150000


SELECT memberRef, memberName, 
(select phone from tbl_member where memberRef = oid) as 전번,
(select points from tbl_member where memberRef = oid) as 잔여포인트, 
(select date(creDateTime) from tbl_member where memberRef = oid) as 가입일, 
(select id from tbl_member where memberRef = oid) as ID, round((SUM( pointPrice )/3),0) AS 평균사용금액, count(oid) as 결제횟수
FROM tbl_order
WHERE consummerRef not in (0,40,47)
    AND state IN (2,5)
    AND useDateTime between "2020-02-01 00:00:00" and "2020-04-30 23:59:59"
GROUP BY memberRef
having 결제횟수 >=15





-- promotionRef가 없는 애들 찾기 -광용님/ 근데 이거 업데이트다 조심. 셀렉트로 바꿔 진하야 메롱 :P
update tbl_pointCode pc
set pc.promotionRef = (select pg.promotionRef from tbl_pointCodeGroup pg where pg.oid = pc.groupRef)
where pc.code = '2691443125143132';



SELECT memberRef,memberName,sum(orderPrice) as 사용금액,
 count(oid), 
 (select sum(points) from tbl_pointCode b where state =3 and a.memberRef = b.memberRef and registDateTime between '2020-03-01 00:00:00' and '2020-03-31 23:59:59') as 등록금액,
 (select count(oid) from tbl_pointCode b where state =3 and a.memberRef = b.memberRef and registDateTime between '2020-03-01 00:00:00' and '2020-03-31 23:59:59') as 등록횟수, 
 (select sum(salePrice) from tbl_pointCode b where state =3 and a.memberRef = b.memberRef and registDateTime between '2020-03-01 00:00:00' and '2020-03-31 23:59:59') as 판매금액합   
 FROM tbl_order a
 WHERE consummerRef > 0 and companyPoints = 0 and payPrice = 0 and state =2 and `useDateTime` between '2020-03-01 00:00:00' and '2020-03-31 23:59:59'
group by memberRef
order by rand()
limit 500


SELECT memberRef,memberName,sum(orderPrice) as 사용금액,
 count(oid)
 FROM tbl_order a
 WHERE consummerRef > 0 and companyPoints = 0 and payPrice = 0 and state =2 and `useDateTime` between '2020-03-01 00:00:00' and '2020-03-31 23:59:59'
group by memberRef
order by rand()
limit 500



#######################################################
부정사용

SELECT year(useDateTime),month(useDateTime),memberRef,memberName,(select id from tbl_member where memberRef = oid) as id,(select phone from tbl_member where memberRef = oid) as phone, shopName, SUM( pointPrice ) as 총사용금액
FROM `tbl_order`
WHERE memberRef = 193894
and state =2
and pointPrice > 0
and useDateTime >= '2020-07-01 00:00:00' 
and useDateTime < '2020-10-01 00:00:00'
GROUP BY year(useDateTime),month(useDateTime), memberRef
,consummerRef 
having sum(pointPrice) >= 10000000


select promotionRef,memberRef,memberName, 
memberPhone, 
(select id from tbl_member where memberRef = oid) as id, 
(select name from tbl_promotion where promotionRef = oid) as 프로모션, 
sum(points) as 총등록금액,
count(oid) as 등록횟수
from tbl_pointCode
where  state = 3 -- 등록완료
and registDateTime >= '2020-07-01 00:00:00' 
and registDateTime < '2020-10-01 00:00:00'
group by promotionRef, memberRef
having 등록횟수 > 4  and 총등록금액 >= 5000000
