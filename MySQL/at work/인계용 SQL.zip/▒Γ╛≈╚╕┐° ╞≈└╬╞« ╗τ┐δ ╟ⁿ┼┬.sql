# 김우재 팀장에게 기업회원 포인트 사용 형태 전달
SELECT YEAR(approveDateTime) as year, MONTH(approveDateTime) as month, companyRef, 
(SELECT companyName FROM tbl_company WHERE oid = a.companyRef) as companyName,
sum(orderPrice), sum(pointPrice), sum(couponPrice), sum(payPrice), sum(companyPoints)
FROM tbl_order as a
WHERE
    companyRef > 0
    AND state = 2
    AND orderPrice > 0
GROUP BY YEAR(approveDateTime), MONTH(approveDateTime), companyRef