8591558888770728 - 내가 쓴 금액권 바코드로 데이터를 찾아보았다.


tbl_order 

기존의 결제 테이블과 차이점은 orderPrice에 머지플러스에서 할인한 금액을 제외한 순결제금액만 찍힌다.


tbl_pg_payment 

order 테이블과 동일


tbl_benefitPayment

여기서는 결제 원가와 함께 할인된 금액이 보인다. 

select state, franchiseID as consummerRef, code, costPrice, paycoPrice
from tbl_benefitPayment
where 1 = 1



900848602184 - 본죽 메뉴권 바코드이다

tbl_order

위와 동일

tbl_pg_payment 

order 테이블과 동일


tbl_benefitPayment

여기서는 결제 원가와 함께 할인된 금액이 보인다. 

tbl_payMenuHistory

메뉴 상세 사용내역