# crowdPay에서 직원 포인트, 식권 사용 내역 추출
SELECT oid
    ,memberRef
    ,
   (SELECT name
      FROM tbl_member
      WHERE oid = a.memberRef
   ) AS memberName,
   (SELECT phone
      FROM tbl_member
      WHERE oid = a.memberRef
   ) AS memberPhone,
   departRef,
(SELECT (select name from tbl_comDepart where oid = departRef)
      FROM tbl_member
      WHERE oid = a.memberRef
   ) AS departName,
   companyRef,
   (SELECT companyName
      FROM tbl_company
      WHERE
         oid = a.companyRef
   ) AS companyName,
   shopRef, shopName,
   paymentRef, payShopRef,
   allocatePoint, remainPoints, remainTicketPoints,
   remainPoints + remainTicketPoints as sumPrice,
   returnPoints,
   approveDateTime as approveDateTime
FROM tbl_crowdPay AS a
WHERE
   paymentRef IN (
      SELECT oid
      FROM tbl_payment
         WHERE useState in (2,3)
         and settlementState in (2,3)
         AND payDateTime >= "2018-12-01 00:00:00"
         AND payDateTime < "2019-01-01 00:00:00"
   )
   AND approveState = 2
   and useState in (2,3)
and companyRef = 33;

select * from tbl_crowdPay
where allocatePoint != remainPoints + remainTicketPoints
and payMentRef = 31664;

select * from tbl_payment
where oid = 31664;

select * from tbl_payment;

select sum(orderPrice) from tbl_use
where shopRef = 196
and settlementState = 2
and date_format(useDateTime,'%Y') = 2018
and date_format(useDateTime,'%m') = 8;


select * from tbl_use;

select sum(a.companyPoints) from tbl_use a
inner join tbl_payment b
on a.paymentRef = b.oid
and a.memberRef = b.memberRef
and a.companyRef = b.companyRef
where a.companyRef = 33
         and useDateTime >= "2018-11-01 00:00:00"
         and useDateTime < "2018-11-24 00:00:00"
         and a.settlementState = 2;
         
         select * from tbl_payment;
         
         
         select * from tbl_use;
         
         #3740
         select * from tbl_crowdPay
         where shopName = '돈까스이야기'
         and companyRef = 33
         and approveState = 2
         and useState = 3
		 AND creDateTime >= "2018-11-01 00:00:00"
         AND creDateTime < "2018-11-24 00:00:00";
         and payMentRef in(16332,23683);
         


select * from tbl_payment
where oid = 24120;
#16332, 23683

select * from tbl_use
where paymentRef = 24120;


select * from tbl_crowdPay
where paymentRef = 24120;

#3740
select * from tbl_pointsHistory
where memberRef = 3740;


select * from tbl_use;

#oid = 4232
select * from tbl_member
where name = '이설이';

#oid = 25678
select * from tbl_payment
where memberRef = 4232;

select * from tbl_payment
where oid = 25675;

select * from tbl_order;
2
select * from tbl_use
where paymentRef = 25678;

select * from tbl_pointsHistory
where memberRef = 4232;

select * from tbl_codeCoupon;

select * from tbl_payment;