-- tbl_crowdPay에서  직원 포인트 사용 내역 읽기
SELECT oid, memberRef,
   (SELECT name
      FROM tbl_member
      WHERE oid = a.memberRef
   ) AS memberName, 
   (SELECT phone
      FROM tbl_member
      WHERE oid = a.memberRef
   ) AS memberPhone, 
   companyRef,
   (SELECT companyName
      FROM tbl_company
      WHERE
         oid = a.companyRef
   ) AS companyName,
   (SELECT departRef
      FROM tbl_member
      WHERE oid = a.memberRef
   ) AS departRef, 
   (SELECT name
      FROM tbl_comDepart
      WHERE oid = (
         SELECT departRef
         FROM tbl_member
         WHERE oid = a.memberRef)) AS departName,
   payShopRef, shopRef, shopName,
   allocatePoint, remainPoints, remainTicketPoints,
   approveDateTime
FROM tbl_crowdPay AS a
WHERE
   paymentRef IN (
      SELECT oid
      FROM tbl_payment
      WHERE
         useState = 3
         AND payDateTime >= "2018-10-01 00:00:00"
         AND payDateTime <= "2018-11-01 00:00:00"
   )
   AND approveState = 2

-- tbl_use에서 해당월 기업 포인트 사용 내역 읽기
SELECT *
FROM tbl_use
WHERE
   companyPoints > 0
   AND useType = 2
   AND useDateTime >= "2018-10-01 00:00:00"
   AND useDateTime <= "2018-11-01 00:00:00"

-- tbl_order에서 해당월 기업 포인트 사용 내역 읽기
SELECT a.*,
   (SELECT name
      FROM tbl_comDepart
      WHERE oid = (
         SELECT departRef
         FROM tbl_member
         WHERE oid = a.memberRef)) AS departName
FROM tbl_order AS a
WHERE
   companyPoints > 0
   AND state = 2
   AND useDateTime >= "2018-10-01 00:00:00"
   AND useDateTime <= "2018-11-01 00:00:00"

-- accn_monthCompany에서 기업 부서별 사용 내역 읽기
SELECT a.*,
   (SELECT companyName
      FROM tbl_company
      WHERE oid = a.companyRef) AS companyName,
   (SELECT name
      FROM tbl_comDepart
      WHERE oid = a.departRef) AS departName
FROM accn_monthCompany AS a
WHERE
   year = 2018
   AND month = 10


SELECT a . * ,
   (
      SELECT companyRef
      FROM tbl_member
      WHERE oid = a.memberRef
   ) AS companyRef
FROM tbl_payShop AS a
WHERE companyPoints >0
AND useState IN ( 2, 3 ) 
AND payDateTime >=  "2018-10-01 00:00:00"
AND payDateTime <=  "2018-11-01 00:00:00"




SELECT paymentRef,
   SUM(allocatePoint), SUM(remainPoints), SUM(remainTicketPoints),
   approveDateTime
FROM tbl_crowdPay AS a
WHERE
   paymentRef IN (
      SELECT oid
      FROM tbl_payment
      WHERE
         companyRef =28
         AND useState = 3
         AND payDateTime >= "2018-09-01 00:00:00"
         AND payDateTime <= "2018-10-01 00:00:00"
   )
   AND approveState = 2
   GROUP BY paymentRef


   -- 정손 code
select A.oid, A.name , 
D.memberRef, 
(select name from tbl_member T where T.oid = D.memberRef),
(select phone from tbl_member T where T.oid = D.memberRef),
 B.companyName, 
 C.shopName, DATE(C.payDateTime),
 timestamp(C.payDateTime) ,
 D.remainPoints,
 D.remainTicketPoints,
 D.oid
 from tbl_member A
join tbl_company B
on A.companyRef = B.oid
join tbl_payShop C
on A.oid = C.memberRef
join tbl_crowdPay D
on D.paymentRef = C.paymentRef
and D.shopRef = C.shopRef
and C.oid = D.payshopRef
and D.approveState = 2
where C.settlementState in (3,2)
and C.useState in (2,3)
and DATE(C.payDateTime) >= "2018-10-01 00:00:00"
and DATE(C.payDateTime) < "2018-11-01 00:00:00"
order by B.companyName,C.payDateTime;




-- 추가로 만든 query
SELECT memberRef, companyRef, sum(allocatePoint), sum(remainPoints), sum(remainTicketPoints), sum(returnPoints) FROM `tbl_crowdPay` AS a
WHERE 1
and memberRef IN ( 3740, 3665, 3611, 3643, 3731, 3760, 3767, 3577 )
and paymentRef = (
    select oid
    from tbl_payment
    where
        oid = a.paymentRef
        and settlementState IN (2, 3)
        and useState IN (2, 3)
    )
and approveState = 2
and approveDateTime >= "2018-10-01"
and approveDateTime < "2018-11-01"
group by memberRef


SELECT paymentRef, shopName,sum(companyPoints) FROM `tbl_use` WHERE 1
and useType = 2
and companyRef = 33
and companyPoints > 0
and useDateTime >= "2018-10-01"
and useDateTime < "2018-11-01"
group by paymentRef


SELECT * 
FROM  `tbl_use` 
WHERE  `orderPrice` != pointPrice + companyPoints + mergeCouponPrice + shopCouponPrice + payPrice
AND  `useType` =2


SELECT * 
FROM  `tbl_order` 
WHERE  `orderPrice` != pointPrice + companyPoints + couponPrice + payPrice