SELECT DATE( useDateTime ) AS useDate, SUM( orderPrice ) , SUM( pointPrice ) 
FROM tbl_order
WHERE useDateTime >=  "2018-12-01 00:00:00"
AND state =2
GROUP BY useDate

SELECT DATE( payDateTime ) AS payDate, SUM( orderPrice ) , SUM( pointPrice ) , SUM( accPoints ) , SUM( buyPoints ) ,
    SUM( tampingPoints ), SUM(companyPoints), SUM(mergeCouponPrice), SUM(payPrice)
FROM tbl_payment
WHERE payDateTime >=  "2018-12-01 00:00:00"
AND useState IN (2,3)
GROUP BY payDate

SELECT *
FROM tbl_payment
WHERE
    orderPrice != pointPrice + companyPoints + payPrice
    AND payDateTime >=  "2018-12-01 00:00:00"
    AND useState IN (2,3)

UPDATE tbl_issuedCoupon
SET couponState = 9
WHERE
    expDate <= NOW()
    AND couponState = 3

SELECT *
FROM tbl_issuedCoupon
WHERE
    expDate <= NOW()
    AND couponState < 4