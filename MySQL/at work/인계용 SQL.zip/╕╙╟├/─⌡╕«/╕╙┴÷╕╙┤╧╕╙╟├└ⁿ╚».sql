SELECT a.oid, a.phone,
 a.creDateTime AS 가입일,
 b.registDateTime AS VIP등록일,
  a.name,
  a.point as 보유포인트
  c.membershipState, 
  c.subscriptionState, 
  a.state, 
  a.visitDateTime,
  d.shopName,
  d.pointPrice as 포인트결제금액
  d.payPrice as 카드결제금액
  d.useDateTime as 사용일
FROM tbl_member a
LEFT OUTER JOIN tbl_vip b ON a.oid = b.recommendee
LEFT OUTER JOIN tbl_benefitUser c ON a.oid = c.oid
left outer join tbl_order d on a.oid = d.memberRef
where a.memberRef IN ()
and d.state = 2




