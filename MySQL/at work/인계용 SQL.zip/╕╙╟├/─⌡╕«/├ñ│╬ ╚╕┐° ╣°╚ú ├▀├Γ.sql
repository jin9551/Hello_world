
월별누적 VIP 유저 결제금액
select  month(b.completeDateTime) as 월,
 sum(a.price) as 결제금액,
 b.state, count(distinct a.memberRef) as 결제자수
from tbl_pg_payment a
left outer join tbl_benefitPayment b on a.giftCode = b.code
where
-- 머지플러스 전체 유저의 결제 금액을 뽑고 싶으시면 'a.memberRef IN () and' 여기까지 지우세요 
a.memberRef IN ()
and a.state = 1
and b.completeDateTime >= "2020-06-29 00:00:00"
AND b.completeDateTime < "2020-07-16 00:00:00"
group by b.state, month(b.completeDateTime)
order by month(b.completeDateTime)



월별누적 전체 유저 결제금액
select  month(b.completeDateTime) as 월,
 sum(a.price) as 결제금액,
 b.state, count(distinct a.memberRef) as 결제자수
from tbl_pg_payment a
left outer join tbl_benefitPayment b on a.giftCode = b.code
where
-- 머지플러스 전체 유저의 결제 금액을 뽑고 싶으시면 'a.memberRef IN () and' 여기까지 지우세요 
a.state = 1
and b.completeDateTime >= "2020-06-29 00:00:00"
AND b.completeDateTime < "2020-07-16 00:00:00"
group by b.state, month(b.completeDateTime)
order by month(b.completeDateTime)
-- 일별 유저 결제금액

-- select  date(b.completeDateTime),
--  sum(a.price),
--  b.state, count(distinct a.memberRef)
-- from tbl_pg_payment a
-- left outer join tbl_benefitPayment b on a.giftCode = b.code
-- where
-- a.memberRef IN ()
-- and a.state = 1
-- and b.completeDateTime >= "2020-06-29 00:00:00"
-- AND b.completeDateTime < "2020-07-09 00:00:00"
-- group by b.state, date(b.completeDateTime)
-- order by date(b.completeDateTime)

VIP 유저수 

select date(createTime),count(oid), membershipState
from tbl_benefitUser
where oid IN ()
group by date(createTime),membershipState
order by date(createTime)

전체유저

select date(createTime),count(oid), membershipState
from tbl_benefitUser
where 1=1
group by date(createTime),membershipState
order by date(createTime)



VIP 회원번호 추출

select recommendee, channel
from tbl_vip
where channel LIKE 'KB국민카드2차'
and recommendee is not null

union

select recommendee, channel
from tbl_vip
where channel LIKE '온라인'
and recommendee is not null

union

select recommendee, channel
from tbl_vip
where channel LIKE '카카오플러스친구'
and recommendee is not null

union

select recommendee, channel
from tbl_vip
where channel LIKE 'LG'
and recommendee is not null

union

select recommendee, channel
from tbl_vip
where channel LIKE '네이버'
and recommendee is not null

union

select recommendee, channel
from tbl_vip
where channel LIKE 'KB국민카드'
and recommendee is not null

union

select recommendee, channel
from tbl_vip
where channel LIKE '시티카드'
and recommendee is not null

union

select recommendee, channel
from tbl_vip
where channel LIKE '레진코믹스'
and recommendee is not null

union

select recommendee, channel
from tbl_vip
where channel LIKE '현대엔지니어링'
and recommendee is not null

union

select recommendee, channel
from tbl_vip
where channel LIKE '코오롱'
and recommendee is not null


union

select recommendee, channel
from tbl_vip
where channel LIKE '삼성생명'
and recommendee is not null