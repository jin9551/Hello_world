SELECT count(oid), category
FROM tbl_order
(
       SELECT
          CASE 
             WHEN pointPrice>=0 AND pointPrice <5000 THEN '0-4999원'
             WHEN pointPrice>=5000 AND pointPrice <10000 THEN '5000원-9999원'
             WHEN pointPrice>=10000 AND pointPrice <15000 THEN '10000원-14999원'
             WHEN pointPrice>=15000 AND pointPrice <20000 THEN '15000원-19999원'
             WHEN pointPrice>=20000 AND pointPrice <25000 THEN '20000원-24999원'
             WHEN pointPrice>=25000 AND pointPrice <30000 THEN '25000원-29999원'
             WHEN pointPrice>=30000 AND pointPrice <35000 THEN '30000원-34999원'
             WHEN pointPrice>=35000 AND pointPrice <40000 THEN '35000원-39999원'
             WHEN pointPrice>=40000 AND pointPrice <45000 THEN '40000원-44999원'
             WHEN pointPrice>=45000 AND pointPrice <50000 THEN '45000원-49999원'
             WHEN pointPrice>=50000 AND pointPrice <100000 THEN '5만원-99999원'
             WHEN pointPrice>=100000 AND pointPrice <150000 THEN '10만원-149999원'
             WHEN pointPrice>=150000 AND pointPrice <200000 THEN '15만원-199999원'
             WHEN pointPrice>=200000 AND pointPrice <250000 THEN '20만원-249999원'
             WHEN pointPrice>=250000 AND pointPrice <300000 THEN '25만원-299999원'
             WHEN pointPrice>=300000 AND pointPrice <400000 THEN '30만원-399999원'
             WHEN pointPrice>=400000 AND pointPrice <500000 THEN '40만원-499999원'
             ELSE '50만원이상' 
          END As Category
       FROM
          tbl_order
) as InnerTable
WHERE
consummerRef = 
and state = 2
and useDateTime >= '2020-04-01' and useDateTime < '2020-07-01'

GROUP BY category



select count(oid) as '0-4999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=0 AND pointPrice <5000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '5000원-9999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=5000 AND pointPrice <10000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '10000원-14999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=10000 AND pointPrice <15000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '15000원-19999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=15000 AND pointPrice <20000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '20000원-24999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=20000 AND pointPrice <25000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '25000원-29999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=25000 AND pointPrice <30000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '30000원-34999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=30000 AND pointPrice <35000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '35000원-39999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=35000 AND pointPrice <40000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '40000원-44999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=40000 AND pointPrice <45000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '45000원-49999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=45000 AND pointPrice <50000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '5만원-99999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=50000 AND pointPrice <100000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '10만원-149999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=100000 AND pointPrice <150000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '15만원-199999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=150000 AND pointPrice <200000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '20만원-249999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=200000 AND pointPrice <250000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '25만원-299999원' from tbl_order where consummerRef = 40 and state =2 and  pointPrice>=250000 AND pointPrice <300000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';
select count(oid) '30만원-399999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=300000 AND pointPrice <400000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '40만원-499999원' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=400000 AND pointPrice <500000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '50만원이상' from tbl_order where consummerRef = 40 and state =2 and pointPrice>=500000 and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01';

select count(oid) '전체' from tbl_order where consummerRef = 40 and state =2  and useDateTime >= '2020-04-01' and useDateTime < '2020-05-01'

