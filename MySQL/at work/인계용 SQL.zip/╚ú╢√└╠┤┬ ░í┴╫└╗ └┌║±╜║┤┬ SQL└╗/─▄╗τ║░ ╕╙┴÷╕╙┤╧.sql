/* 
위에서 부터 순서대로

페이즈
스마트콘
머지직연동
즐거운
슈퍼콘
엠트웰브


*/


select year(useDateTime) as year, month(useDateTime) as month, sum(pointPrice) as 머지머니, count(oid) as count
from tbl_order 
where 
consummerRef IN (select oid from tbl_giftConsummer where producerRef =1)
and state =2
and pointPrice>0
and useDateTime >= '2020-12-11 00:00:00' 
and useDateTime < '2020-12-16 00:00:00'
group by year, month

union

select year(useDateTime) as year, month(useDateTime) as month, sum(pointPrice) as 머지머니, count(oid) as count
from tbl_order 
where 
consummerRef IN (select oid from tbl_giftConsummer where producerRef =2)
and state =2
and pointPrice>0
and useDateTime >= '2020-12-11 00:00:00' 
and useDateTime < '2020-12-16 00:00:00'
group by year, month

union

select year(useDateTime) as year, month(useDateTime) as month, sum(pointPrice) as 머지머니, count(oid) as count
from tbl_order 
where 
consummerRef IN (select oid from tbl_giftConsummer where producerRef =3 )
and state =2
and pointPrice>0
and useDateTime >= '2020-12-11 00:00:00' 
and useDateTime < '2020-12-16 00:00:00'
group by year, month

union

select year(useDateTime) as year, month(useDateTime) as month, sum(pointPrice) as 머지머니, count(oid) as count
from tbl_order 
where 
consummerRef IN (select oid from tbl_giftConsummer where producerRef =6)
and state =2
and pointPrice>0
and useDateTime >= '2020-12-11 00:00:00' 
and useDateTime < '2020-12-16 00:00:00'
group by year, month

union

select year(useDateTime) as year, month(useDateTime) as month, sum(pointPrice) as 머지머니, count(oid) as count
from tbl_order 
where 
consummerRef IN (select oid from tbl_giftConsummer where producerRef =7)
and state =2
and pointPrice>0
and useDateTime >= '2020-12-11 00:00:00' 
and useDateTime < '2020-12-16 00:00:00'
group by year, month

union

select year(useDateTime) as year, month(useDateTime) as month, sum(pointPrice) as 머지머니, count(oid) as count
from tbl_order 
where 
consummerRef IN (select oid from tbl_giftConsummer where producerRef =8)
and state =2
and pointPrice>0
and useDateTime >= '2020-12-11 00:00:00' 
and useDateTime < '2020-12-16 00:00:00'
group by year, month;



#############################################

CU


##########################################



select year(useDateTime) as year, date(useDateTime) as date, shopName, sum(pointPrice) as 머지머니, count(oid) as count
from tbl_order 
where 
consummerRef IN (79)
and state =2
and pointPrice>0
and useDateTime >= '2020-12-01 00:00:00' 
and useDateTime < '2020-12-21 00:00:00'
group by year(useDateTime), date, consummerRef
