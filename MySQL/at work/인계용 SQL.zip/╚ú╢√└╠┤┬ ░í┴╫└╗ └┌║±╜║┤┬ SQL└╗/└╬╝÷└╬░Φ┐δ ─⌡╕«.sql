


#######################################################################################################


/* 통계용 쿼리 */


#######################################################################################################

/* 

머지머니 
consummerRef와 날짜만 바꿔주면 된다.



*/

select year(useDateTime) as year, date(useDateTime) as date, shopName, sum(pointPrice) as 머지머니, count(distinct memberRef) as count
from tbl_order 
where 
consummerRef IN (176)
and state =2
and pointPrice>0
and useDateTime >= '2020-12-01 00:00:00' 
and useDateTime < '2020-12-21 00:00:00'
group by year(useDateTime), date, consummerRef

/* 

머지플러스
FranchiseID와 날짜만 변경하면 된다.


*/

select year(completeDateTime) as year, date(completeDateTime) as date, franchiseID,paymentType,(select name from tbl_giftConsummer where oid = franchiseID) as 상호명
 ,sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(distinct memberRef) as count
from tbl_benefitPayment
where state like 'complete'
and franchiseID IN (79)
and completeDateTime >= '2020-12-01 00:00:00' 
and completeDateTime < '2020-12-11 00:00:00'
group by year, date, franchiseID





/*


최초 등록 프로모션 파악용



서브쿼리에서는 promotionRef에 입력된 프로모션을 등록한 사람들을 모아주고
쿼리문에서는 이 사람이 등록한 최초 프로모션이 무엇인지 찾는 쿼리.
Group by를 이용해 가장 먼저 등록한 기록이 위로 오게 만듬.


*/
SELECT promotionRef, (
SELECT name
FROM tbl_promotion
WHERE promotionRef = oid
) AS 프로모션, memberRef, memberName, registDateTime
FROM `tbl_pointCode`
WHERE 
memberRef
IN ( select memberRef from tbl_pointCode where promotionRef IN (373) and state =3 and registDateTime >= '2020-11-27 00:00:00'
)
AND state =3

GROUP BY memberRef






#######################################################################################################


/* 정산용 쿼리 */


#######################################################################################################



/*


가정산


*/




select
a.oid
,a.paymentRef
,a.shopRef
,a.shopName
,a.shopRate
,a.pgRate
,a.memberRate
,a.memberRef
,b.name as memberName
,a.companyRef
,(select companyName from tbl_company as com where a.companyRef = com.oid) as companyName
,b.departRef
,(select name from tbl_comDepart as depart where b.departRef = depart.oid) as departName
,a.menuName
,a.menuPrice
,a.useCount
,a.orderPrice
,a.companyPoints
,(a.payPrice + a.pointPrice) as usePoint
,a.payPrice
,a.pointPrice
,a.buyPoints
,a.tampingPoints
,a.accPoints
,round(a.companyPoints * (a.shopRate / 1000),0) as mergeCompCharge
,round((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )),0) as mergeCharge
,round(a.payPrice * (a.pgRate / 1000),0) as pgCharge
,round(a.payPrice * (a.shopRate / 1000),0) as payPriceCharge
,round(a.pointPrice * (a.shopRate / 1000),0) as pointPriceCharge
,round(a.companyPoints * (a.shopRate / 1000) + (a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )),0) as totalMergeCharge
,round(a.companyPoints - (a.companyPoints * (a.shopRate / 1000)),0) as compSettlement
,round((a.payPrice - (a.payPrice * (a.shopRate / 1000)) - (a.payPrice * (a.pgRate / 1000))) + (a.pointPrice - (a.pointPrice * (a.shopRate / 1000))),0) as usePointSettlement
,round(a.payPrice - (a.payPrice * (a.shopRate / 1000)) - (a.payPrice * (a.pgRate / 1000)),0) as payPriceSettlement
,round(a.pointPrice - (a.pointPrice * (a.shopRate / 1000)),0) as pointPriceSettlement
,round(((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) -
        ((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) / 11)),0) as mergesupply
,round(((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) / 11),0) as mergeVAT
,round((a.companyPoints * (a.shopRate / 1000)) - ((a.companyPoints * (a.shopRate / 1000)/11)),0) as mergeCompsupply
,round((a.companyPoints * (a.shopRate / 1000)/11),0) as mergeCompVAT
,round((a.payPrice * (memberRate)/1000),0) as accumulatePoint
,a.useDateTime as useDateTime
,a.orderRef
,c.barcode
from tbl_use a
left outer join tbl_member b on a.memberRef = b.oid
left outer join tbl_order c on c.oid = a.orderRef
WHERE
        a.shopRef IN (1044,6190,20908,21086,21680,31521,33276,33322,33190,33311)
        -- (20832,1277,1107,1302,33301)
        and a.settlementState IN (2,3)
        AND useType IN (2, 3)
        AND a.useDateTime >= "2020-12-01 00:00:00"
        AND a.useDateTime < "2020-12-16 00:00:00"
ORDER BY a.useDateTime;



/*


일반 매장 정산용


*/





select
a.oid
,a.paymentRef
,a.shopRef
,a.shopName
,a.shopRate
,a.pgRate
,a.memberRate
,a.memberRef
,b.name as memberName
,a.companyRef
,(select companyName from tbl_company as com where a.companyRef = com.oid) as companyName
,b.departRef
,(select name from tbl_comDepart as depart where b.departRef = depart.oid) as departName
,a.menuName
,a.menuPrice
,a.useCount
,a.orderPrice
,a.companyPoints
,(a.payPrice + a.pointPrice) as usePoint
,a.payPrice
,a.pointPrice
,a.buyPoints
,a.tampingPoints
,a.accPoints
,round(a.companyPoints * (a.shopRate / 1000),0) as mergeCompCharge
,round((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )),0) as mergeCharge
,round(a.payPrice * (a.pgRate / 1000),0) as pgCharge
,round(a.payPrice * (a.shopRate / 1000),0) as payPriceCharge
,round(a.pointPrice * (a.shopRate / 1000),0) as pointPriceCharge
,round(a.companyPoints * (a.shopRate / 1000) + (a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )),0) as totalMergeCharge
,round(a.companyPoints - (a.companyPoints * (a.shopRate / 1000)),0) as compSettlement
,round((a.payPrice - (a.payPrice * (a.shopRate / 1000)) - (a.payPrice * (a.pgRate / 1000))) + (a.pointPrice - (a.pointPrice * (a.shopRate / 1000))),0) as usePointSettlement
,round(a.payPrice - (a.payPrice * (a.shopRate / 1000)) - (a.payPrice * (a.pgRate / 1000)),0) as payPriceSettlement
,round(a.pointPrice - (a.pointPrice * (a.shopRate / 1000)),0) as pointPriceSettlement
,round(((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) -
        ((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) / 11)),0) as mergesupply
,round(((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) / 11),0) as mergeVAT
,round((a.companyPoints * (a.shopRate / 1000)) - ((a.companyPoints * (a.shopRate / 1000)/11)),0) as mergeCompsupply
,round((a.companyPoints * (a.shopRate / 1000)/11),0) as mergeCompVAT
,round((a.payPrice * (memberRate)/1000),0) as accumulatePoint
,a.useDateTime as useDateTime
from tbl_use a
left outer join tbl_member b on a.memberRef = b.oid
left outer join tbl_order c on c.oid = a.orderRef
left outer join tbl_giftConsummer d on a.consummerREf = d.oid
where   a.consummerRef = 0
        and a.settlementState IN (2,3)
        AND useType IN (2, 3)
        AND a.useDateTime >= "2020-10-01 00:00:00"
        AND a.useDateTime < "2020-11-01 00:00:00"
ORDER BY a.useDateTime;


/*


전체 매장 정산용


*/



select
a.oid
,a.paymentRef
,a.shopRef
,a.shopName
,a.shopRate
,a.pgRate
,a.memberRate
,a.memberRef
,b.name as memberName
,a.companyRef
,(select companyName from tbl_company as com where a.companyRef = com.oid) as companyName
,b.departRef
,(select name from tbl_comDepart as depart where b.departRef = depart.oid) as departName
,a.menuName
,a.menuPrice
,a.useCount
,a.orderPrice
,a.companyPoints
,(a.payPrice + a.pointPrice) as usePoint
,a.payPrice
,a.pointPrice
,a.buyPoints
,a.tampingPoints
,a.accPoints
,round(a.companyPoints * (a.shopRate / 1000),0) as mergeCompCharge
,round((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )),0) as mergeCharge
,round(a.payPrice * (a.pgRate / 1000),0) as pgCharge
,round(a.payPrice * (a.shopRate / 1000),0) as payPriceCharge
,round(a.pointPrice * (a.shopRate / 1000),0) as pointPriceCharge
,round(a.companyPoints * (a.shopRate / 1000) + (a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )),0) as totalMergeCharge
,round(a.companyPoints - (a.companyPoints * (a.shopRate / 1000)),0) as compSettlement
,round((a.payPrice - (a.payPrice * (a.shopRate / 1000)) - (a.payPrice * (a.pgRate / 1000))) + (a.pointPrice - (a.pointPrice * (a.shopRate / 1000))),0) as usePointSettlement
,round(a.payPrice - (a.payPrice * (a.shopRate / 1000)) - (a.payPrice * (a.pgRate / 1000)),0) as payPriceSettlement
,round(a.pointPrice - (a.pointPrice * (a.shopRate / 1000)),0) as pointPriceSettlement
,round(((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) -
        ((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) / 11)),0) as mergesupply
,round(((a.payPrice * (a.shopRate / 1000) + a.payPrice * (a.pgRate / 1000) + a.pointPrice * (a.shopRate / 1000 )) / 11),0) as mergeVAT
,round((a.companyPoints * (a.shopRate / 1000)) - ((a.companyPoints * (a.shopRate / 1000)/11)),0) as mergeCompsupply
,round((a.companyPoints * (a.shopRate / 1000)/11),0) as mergeCompVAT
,round((a.payPrice * (memberRate)/1000),0) as accumulatePoint
,a.useDateTime as useDateTime
,a.orderRef
,c.barcode
from tbl_use a
left outer join tbl_member b on a.memberRef = b.oid
left outer join tbl_order c on c.oid = a.orderRef
where
      a.settlementState IN (2,3)
        AND useType IN (2, 3)
        AND a.useDateTime >= "2020-11-01 00:00:00"
        AND a.useDateTime < "2020-12-01 00:00:00"
ORDER BY a.useDateTime;


/*


기업 정산용
이것과 전체 매장 정산용을 기업정산할때 주면 된다.



*/



SELECT oid
    ,memberRef
   ,(SELECT name
      FROM tbl_member
      WHERE oid = a.memberRef
   ) AS memberName,
   (SELECT phone
      FROM tbl_member
      WHERE oid = a.memberRef
   ) AS memberPhone,
   (
      SELECT departRef
      FROM tbl_member
      WHERE oid = a.memberRef
   ) as departRef,
  
   (SELECT name from tbl_comDepart where oid = departRef
   ) AS departName,
   companyRef,
   (SELECT companyName
      FROM tbl_company
      WHERE
         oid = a.companyRef
   ) AS companyName,
   shopRef, shopName,
   paymentRef, payShopRef,
   allocatePoint, remainPoints, remainTicketPoints,
   remainPoints + remainTicketPoints as sumPrice,
   returnPoints,
   approveDateTime as approveDateTime
FROM tbl_crowdPay AS a
WHERE
   paymentRef IN (
      SELECT oid
      FROM tbl_payment
         WHERE useState in (2,3)
         AND settlementState in (2,3)
         AND payDateTime >= "2020-11-01 00:00:00"
         AND payDateTime < "2020-12-01 00:00:00"
   )
   AND allocatePoint != 0
   AND approveState = 2
   AND useState in (2,3);




/*

콘사 정산용 금액권 edition

producerRef 

= 1 페이즈
= 2 스마트콘

*/



# 결제만 뽑기
# 이거만 쓰세유


select 
b.oid,
shopName,
barCode, 
b.state, ifnull(a.state,'머지머니총액권') as 베네핏상태, ifnull(a.paymentType,'머지머니총액권') as 금액구분,
orderPrice, 
pointPrice, 
payPrice, 
round((payPrice * 1.25),0) as originPrice, 
useDateTime
from tbl_order b
left outer join tbl_benefitPayment a on a.code = b.barCode
where barCode in (
    select code 
    from tbl_payCodeGenerate
    where producerRef = 7
        and state IN (2)
        and modifyTime >= '2020-11-01 00:00:00'
        and modifyTime < '2020-12-01 00:00:00' 
        )
    and useDateTime >= '2020-11-01 00:00:00' 
    and useDateTime < '2020-12-01 00:00:00';


# 취소 + 결제 같이 뽑기 

select 
b.oid,
shopName,
barCode, 
b.state, 
ifnull(a.state,'머지머니총액권') as 베네핏상태, 
ifnull(a.paymentType,'머지머니총액권') as 금액구분,
orderPrice, 
pointPrice, 
payPrice, 
round((payPrice * 1.25),0) as originPrice, 
useDateTime
from tbl_order b
left outer join tbl_benefitPayment a on a.code = b.barCode
where barCode in (
    select code 
    from tbl_payCodeGenerate
    where producerRef = 1
        and state IN (1,2)
        and modifyTime >= '2020-11-01 00:00:00'
        and modifyTime < '2020-12-01 00:00:00' 
        )
    and useDateTime >= '2020-11-01 00:00:00' 
    and useDateTime < '2020-12-01 00:00:00';







# 본죽 대사 자료용 

select 
oid,
case when consummerRef = 86 then '본죽'
     when consummerRef = 87 then '본도시락'
     else '본죽&비빔밥' 
     end as 상호명, 
barCode, 
case when state = 2 then 'complete'
     else 'cancel'
     end as state,
orderPrice, 
pointPrice, 
payPrice, 
round((payPrice * 1.25),0) as originPrice, 
useDateTime, 
(
    select distinct shopCode 
    from tbl_paysUseInfo
    where giftCode = b.barCode
) as shopCode
from tbl_order b
where barCode in (
    select code 
    from tbl_payCodeGenerate
    where consummerRef IN (86,87,92)
        and paymentType IN (1)
        and date_format(modifyTime, '%Y-%m') >= '2020-11' 
        )
    and useDateTime >= '2020-11-01 00:00:00' 
    and useDateTime < '2020-12-01 00:00:00';







/*

콘사 정산용 메뉴권 edition

written by Jake Park

producerRef 

= 4 KTMhows
= 6 즐거운
= 8 M12

*/


# 날짜는 이거로도 변경 가능하지만 추천은 하지 않음. 
date_format(a.createTime, '%Y-%m') >= '2020-10' 



SELECT 
case 
    when a.state = 3 thEn '사용완료'
    when a.state = 3 AND b.cancelState = 1 thEn '사용완료(상품권취소됨)'
    when a.state = 12 thEn '사용취소'
    when a.state = 12 AND b.cancelState = 0 thEn '사용취소요청(취소불가)'
    ELSE  '유저요청 취소'
END as '상태'
,a.originPrice, a.salePrice,a.payPrice,b.*, (select name from tbl_giftConsummer d where c.consummerRef=d.oid) as 이름
FROM tbl_payMenuHistory a, tbl_GiftMenuEvent b, tbl_giftMenu c
where a.barcode = b.barcodeNum
and b.MenuRef = c.oid
and c.producerRef = 6
and a.createTime >= '2020-11-01 00:00:00'
and a.createTime < '2020-12-01 00:00:00' 
order by a.createTime asc
;





/*


바우처 정산용


*/


SELECT oid,(select name from tbl_promotion where promotionRef = oid) as 프로모션, 
promotionRef, code, (
SELECT groupName
FROM tbl_pointCodeGroup
WHERE oid = pcode.groupRef
) AS 금액권명, points, registDateTime AS 등록일시
FROM `tbl_pointCode` AS pcode
WHERE `promotionRef`
IN (select oid from tbl_promotion where sellerRef = 4)
AND state =3
AND registDateTime >= '2020-11-01 00:00:00'
AND registDateTime < '2020-12-01 00:00:00' 
