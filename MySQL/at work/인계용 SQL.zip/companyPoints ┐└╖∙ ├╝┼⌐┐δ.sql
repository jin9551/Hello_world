# companyPoints 이상 회원 추출
SELECT *
FROM tbl_member
WHERE state = 1
AND companyRef > 0
AND (
        companyPoints > companyTotalPoints
        OR companyPoints < 0
        OR companyTotalPoints < 0
    )

# 20190212
# member 3929, 3836, 4195

# 20190304
# member 3285, 3332, 3486, 3631, 36327, 39030, 39035, 39462

# 20190613
# member 3078, 3127, 3137, 3152, 3418


# comPointHistory 데이터 추출
SELECT memberRef, SUM( ticketUnitPrice * remainTicketCount ) as ticketPrice, SUM( remainPoint ) as pointPrice,
    SUM( ticketUnitPrice * remainTicketCount + remainPoint ) as totalPointPrice
FROM  `tbl_comPointHistory` 
WHERE memberRef IN ( 3285,3321,3331,3826,4195 ) 
GROUP BY memberRef
ORDER BY  `tbl_comPointHistory`.`memberRef` ASC 

SELECT * 
FROM  tbl_comPayPoint
WHERE  memberRef IN ( 3285,3333,3388,3539 ) 
ORDER BY  paymentRef DESC, memberRef ASC 

SELECT *
FROM tbl_comPayPoint
WHERE paymentRef IN ( ... )
ORDER BY paymentRef ASC

# 오류 crowdPay 찾기 - code 분리

SELECT oid, memberRef, paymentRef, payShopRef, creDateTime, (remainTicketPoints + usePoints) AS crowdPayPrice,
    (SELECT SUM(usePoint + ticketPrice - returnPoints)
        FROM tbl_comPayPoint
        WHERE crowdPayRef = a.oid
        GROUP BY crowdPayRef
    ) AS comPayPointPrice
FROM tbl_crowdPay AS a
WHERE
    approveState = 2
    AND creDateTime >= "2019-01-15 00:00:00"
ORDER BY oid ASC

# --- new code
# -- comPayPoint에 이중으로 등록된 내역을 찾아서 지우고, comPointsHistory에서도 해당 comPayPointRef를 지운다.
# crowdPay check
SELECT oid, memberRef, paymentRef, payShopRef, allocatePoint, remainPoints, remainTicketPoints,  returnPoints, creDateTime
FROM tbl_crowdPay
WHERE
    approveState = 2
    AND allocatePoint > 0
    AND creDateTime >= "2019-08-01 00:00:00"
    AND creDateTime < "2019-09-01 00:00:00"
ORDER BY oid ASC

# comPayPoint check
SELECT crowdPayRef, SUM(usePoint) AS pointPrice, SUM(ticketPrice - returnPoints) AS ticketPrice
FROM tbl_comPayPoint
WHERE
    crowdPayRef IN (
        SELECT oid
        FROM tbl_crowdPay
        WHERE
            approveState = 2
            AND creDateTime >= "2019-08-01 00:00:00"
            AND creDateTime < "2019-09-01 00:00:00"
    )
GROUP BY crowdPayRef
ORDER BY crowdPayRef ASC

# 20190111
# member (3285,3333,3388,3539)
# payment (57726,57843,57891)

# 20190130
# member ( 3285,3321,3331,3826,4195 )
# payment ( 68374,67640,64887,67720,66491,67688 )
# order ( 51233,52657,53665,53686,53175,54288 )

# 20190212
# point diff (72637)
# ticket diff (75379)

# 20190221
# crowdPay (76626,76680,77453,77551,77552,77553,77554,77619,78295,78412,78501,78503,78526,80297,80458,81236,81241,81242,81243,81244,81622)

# 20190318 - 결제 취소 시, comPayPoint에 returnPoint가 지워짐.

# 20190701
# crowdPay Ref - 133272, 137888, 139510, 139945, 144467

# 20190902
# crowdPay Ref - 160402, 160523, 160526, 160541, 160560, 160602, 160605, 160625, 160619



