SELECT YEAR(creDateTime) AS 사용년도, MONTH(creDateTime) AS 사용월,
    SUM(buyPoints) AS buyPoints
FROM tbl_pointsHistory
WHERE
    totalPoints = 0
    AND type = 1
    AND reason NOT LIKE "%취소%"
    AND reason NOT LIKE "%만료%"
    AND reason NOT LIKE "%환불%"
    AND reason NOT LIKE "%회수%"
    AND creDateTime >= "2019-05-01 00:00:00"
    AND creDateTime < "2019-11-01 00:00:00"
GROUP BY
    YEAR(creDateTime), MONTH(creDateTime)