# shopApp 사용 점포 - 이태권
SELECT oid, shopName, shopPhone, postcode, address01, address02, ownerName, ownerPhone,
    (SELECT MAX(visitDateTime)
        FROM tbl_shopAuthInfo
        WHERE
            shopRef = a.oid
    ) AS visitTime
FROM tbl_shop AS a
WHERE
    oid IN (
        SELECT shopRef
        FROM tbl_shopAuthInfo
        WHERE 1
    )



# 기업포인트 사용 내역 - 이승연 팀장
SELECT *,
    (SELECT name
    FROM tbl_member
    WHERE
        oid = a.memberRef) AS memberName,
    (SELECT companyName
    FROM tbl_company
    WHERE
        oid = a.companyRef) AS companyName
FROM tbl_crowdPay AS a
WHERE
    paymentRef IN (
        SELECT oid
        FROM tbl_payment
        WHERE
            useState IN (2,3)
            AND settlementState IN (2, 3)
            AND payDateTime >= "2019-01-01 00:00:00"
            AND payDateTime < "2019-02-01 00:00:00"
    )
    AND approveState = 2

# 개인포인트 이용 내역 - 조미나
SELECT DATE(creDateTime), totalPoints, shopName, paymentRef
FROM tbl_pointsHistory
WHERE memberRef = 10370 AND totalPoints > 0

# use에서 프랜차이즈 사용 이력 추출
SELECT *, useDateTime AS appDT
FROM  tbl_use AS a
WHERE orderRef IN (
    SELECT oid
    FROM tbl_order
    WHERE
        barCode IS NOT NULL
        AND state IN (2, 5)
        AND approveDateTime >=  "2018-12-01 00:00:00"
        AND approveDateTime <  "2019-01-01 00:00:00"
)


# order에서 프랜차이즈 사용 이력 추출
SELECT *, approveDateTime AS appDT
FROM tbl_order
WHERE
    barCode IS NOT NULL
    AND state IN (2, 5)
    AND approveDateTime >=  "2018-12-01 00:00:00"
    AND approveDateTime <  "2019-01-01 00:00:00"


# 일반 포인트 사용 내역 - 조미나
SELECT DATE(payDateTime) AS payDateTime, SUM(pointPrice) AS 일반포인트합, SUM(accPoints) AS 적립포인트,
SUM(buyPoints) AS 구매포인트, SUM(tampingPoints) AS 지급포인트
FROM tbl_payment
WHERE
    settlementState IN (2, 3)
    AND useState IN (2, 3)
    AND payDateTime >= "2019-05-20 00:00:00"
    AND payDateTime < "2019-05-27 00:00:00"
GROUP BY DATE(payDateTime)

# 샐러디 사용 이력
SELECT *,
    (SELECT companyName
        FROM tbl_company
        WHERE oid = a.companyRef
    ) AS companyName
FROM tbl_use AS a
WHERE
    shopRef IN (
        SELECT oid
        FROM tbl_shop
        WHERE
            shopName LIKE "%샐러디%"
        )
    AND settlementState IN (2, 3)
    AND useType IN (2,3)



SELECT * FROM `tbl_payShop`
WHERE
    shopRef = 1158
    AND settlementState = 3
    AND payDateTime >= "2019-01-23 00:00:00"
    AND payDateTime < "2019-01-24 00:00:00"

# 회원 정보 기업정보, 폰 기종 포함 - 조미나
SELECT oid, id, name, phone, email, postcode, address01, address02, gender, companyRef,
    (CASE
        WHEN companyRef = 0 THEN "일반회원"
        ELSE
            (SELECT companyName
                FROM tbl_company
                WHERE oid = m.companyRef)
    END) AS companyName,
    companyPoints, points, accPoints, buyPoints, tampingPoints, osType,
    (CASE
        WHEN osType = 0 THEN "logout"
        WHEN osType = 1 THEN "android"
        WHEN osType = 2 THEN "iphone"
        WHEN osType = 3 THEN "web"
        WHEN osType = 4 THEN "iphonePay"
    END) AS appType,
    creDateTime AS 가입일, 
    visitDateTime AS 최종방문일
FROM tbl_member AS m
WHERE
    state = 1

# 2018년 이용 현황 - 이승연
SELECT *
FROM tbl_use
WHERE
    settlementState IN (2, 3)
    AND useType IN (2,3)
    AND useDateTime >= "2018-01-01 00:00:00"
    AND useDateTime < "2019-01-01 00:00:00"

# 포인트 적립 현황 회원별 - 이승연
SELECT oid, memberRef, accPoints, buyPoints, tampingPoints, remainPoints, reason, creDateTime, expDateTime
FROM tbl_pointsHistory
WHERE
    memberRef > 0
    AND type = 1
    AND totalPoints = 0

# 포인트 적립 현황 일자별 - 조미나
SELECT DATE(creDateTime) AS 날짜,
    SUM(totalPoints) AS 전체포인트, SUM(accPoints) AS 적립포인트, SUM(buyPoints) AS 구매포인트, SUM(tampingPoints) AS 지급포인트, SUM(remainPoints) AS 남은포인트
FROM tbl_pointsHistory
WHERE
    memberRef > 0
    AND type = 1
    AND reason NOT LIKE "%취소%"
    AND reason NOT LIKE "%만료%"
    AND DATE(creDateTime) >= "2019-02-26 00:00:00"
    AND DATE(creDateTime) < "2019-03-07 00:00:00"
GROUP BY DATE(creDateTime)

# 2/11일 가입자 - 조상현
SELECT *
FROM tbl_member
WHERE
    state = 1
    AND useCount > 0
    AND DATE(creDateTime) >= "2019-02-11 00:00:00"
    AND DATE(creDateTime) < "2019-02-12 00:00:00"

# 회원 포인트 이력 - 조상현
SELECT oid, memberRef, shopName, TYPE , reason, totalPoints, creDateTime
FROM  `tbl_pointsHistory`  AS a
WHERE totalPoints >0
    AND memberRef IN ( SELECT oid
FROM tbl_member
WHERE
    state = 1
    AND useCount > 0
    AND DATE(creDateTime) >= "2019-02-11 00:00:00"
    AND DATE(creDateTime) < "2019-02-12 00:00:00" ) 

# 월별 포인트 발급 현황 - 조미나
SELECT YEAR(creDateTime) AS 발행년도, MONTH(creDateTime) AS 발행월,
        SUM(totalPoints) AS 포인트합, SUM(accPoints) AS 적립포인트, SUM(buyPoints) AS 구매포인트, SUM(tampingPoints) AS 지급포인트
FROM tbl_pointsHistory
WHERE
    type = 1
    AND DATE(creDateTime) >= "2018-10-01 00:00:00"
    AND DATE(creDateTime) < "2019-03-01 00:00:00"
GROUP BY
    YEAR(creDateTime), MONTH(creDateTime)

# pays 결제 사용 금액 - 김주은
SELECT YEAR(approveDateTime) AS 사용년도, MONTH(approveDateTime) AS 사용월,
        SUM(orderPrice) AS 사용금액, SUM(pointPrice) AS 포인트합, SUM(companyPoints) AS 기업포인트, SUM(payPrice) AS 결제금액
FROM tbl_order
WHERE
    state = 2
    AND barCode IS NOT NULL
GROUP BY
    YEAR(approveDateTime), MONTH(approveDateTime)

# 포인트 구분 - 김주은
SELECT YEAR(useDateTime) AS 사용년도, MONTH(useDateTime) AS 사용월,
        SUM(orderPrice) AS 사용금액, SUM(pointPrice) AS 포인트합, SUM(accPoints) AS 적립포인트, SUM(buyPoints) AS 구매포인트, SUM(tampingPoints) AS 적립포인트,
        SUM(companyPoints) AS 기업포인트, SUM(payPrice) AS 결제금액
FROM tbl_use
WHERE orderRef IN (
    SELECT oid
    FROM tbl_order
    WHERE
        state = 2
        AND barCode IS NOT NULL
    )
GROUP BY
    YEAR(useDateTime), MONTH(useDateTime)

# 봉구스 밥버거 이용 내역 - 우태준
SELECT *
FROM tbl_payShop
WHERE
    shopRef = 1125
    AND DATE(payDateTime) >= "2019-02-27 00:00:00"
    AND DATE(payDateTime) < "2019-02-28 00:00:00"

# 포인트 발행 및 사용량 정보 월별
# 포인트 발행
SELECT YEAR(creDateTime) AS 사용년도, MONTH(creDateTime) AS 사용월,
    SUM(buyPoints) AS 구매포인트발행, SUM(accPoints)  AS 적립포인트발행, SUM(tampingPoints) AS 지급포인트발행
FROM tbl_pointsHistory
WHERE
    totalPoints = 0
    AND type = 1
    AND reason NOT LIKE "%취소%"
    AND creDateTime >= "2019-01-01 00:00:00"
GROUP BY
    YEAR(creDateTime), MONTH(creDateTime)

# 일별 발행
SELECT YEAR(creDateTime) AS 발행년도, MONTH(creDateTime) AS 발행월,
    DAY(creDateTime) AS 발행일,
    SUM(buyPoints) AS 구매포인트발행, SUM(accPoints)  AS 적립포인트발행, SUM(tampingPoints) AS 지급포인트발행
FROM tbl_pointsHistory
WHERE
    totalPoints = 0
    AND type = 1
    AND reason NOT LIKE "%취소%"
    AND creDateTime >= "2019-03-01 00:00:00"
GROUP BY
    YEAR(creDateTime), MONTH(creDateTime), DAY(creDateTime)

# 포인트 잔액
SELECT YEAR(creDateTime) AS 사용년도, MONTH(creDateTime) AS 사용월,
    SUM(remainPoints)  AS 구매포인트잔액
FROM tbl_pointsHistory
WHERE
    buyPoints > 0
    AND type = 1
GROUP BY

    YEAR(creDateTime), MONTH(creDateTime)


# 분석용 회원 정보 - 조미나
SELECT oid, name, id, phone, creDateTime AS 가입일, gender, visitDateTime AS 최종방문일, state, osType, points,
    (
        SELECT MIN(registDateTime)
        FROM tbl_pointCode
        WHERE
            memberRef = a.oid
    ) AS 최초적립일,
    (
        SELECT COUNT(oid)
        FROM tbl_pointCode
        WHERE
            memberRef = a.oid
    ) AS 적립횟수,
    (
        SELECT count(oid)
        FROM tbl_payShop
        WHERE
            memberRef = a.oid
            AND settlementState IN (2, 3)
            AND useState IN (2, 3)
            AND shopType = 1
    ) AS 일반매장사용,
    (
        SELECT count(oid)
        FROM tbl_payShop
        WHERE
            memberRef = a.oid
            AND settlementState IN (2, 3)
            AND useState IN (2, 3)
            AND shopType = 4
    ) AS 프랜차이즈사용,
    (
        SELECT count(oid)
        FROM tbl_payShop
        WHERE
            memberRef = a.oid
            AND settlementState IN (2, 3)
            AND useState IN (2, 3)
            AND payPrice > 0
    ) AS 카드결제
FROM tbl_member AS a
WHERE oid IN (819,820,821,822,824,825,840,844,847,849,850,852,853,854,855,857,858,860,861,863,1637,1638,1640,1641,1642,1643,1644,1645,1646,1648,2365,2371,2380,2399,2420,2422,2465,2498,2526,2559,2599,2618,2639,2649,2652,2658,2686,2696,2704,2708,4012,4029,4035,4043,4051,4052,4054,4057,4068,4101,4105,4107,4110,4119,4124,4137,4143,4147,4172,4196,4197,4215,4216,4217,4288,4312,4317,4350,4356,4392,4422,4426,4436,4449,4453,4457,4479,4491,4511,4538,4545,4573,4597,4654,4661,4725,4743,4756,4771,4779,4844,4853,4898,4911,4934,4946,4968,4986,5031,5044,5052,5061,5091,5138,5148,5154,5175,5200,5216,5218,5220,5237,5238,5250,5252,5337,5351,5495,5500,5524,5526,5529,5543,5580,5599,5604,5613,5650,5659,5777,5780,5797,5799,5833,5850,5868,5872,8522,8523,8573,8579,8584,8592,8622,8634,8635,8657,8686,8690,8723,8729,8731,8768,8790,8793,8821,8823,8854,8871,8885,8932,8945,8973,8997,9083,9101,9132,9154,9168,9185,9212,9224,9247,9259,9262,9266,9289,9324,9440,9523,9527,9574,9579,9612,9682,9716,9746,9748,9771,9774,10425,10512,10525,10533,10537,10547,10551,10561,10574,10591,10632,10658,10677,10711,10735,10934,10935,11038,11055,11088,11104,11122,11157,11198,11208,11228,11243,11277,11315,11323,11342,11350,11393,11411,11436,11859,11902,11937,11969,11986,11995,12038,12041,12049,12054,12073,12114,12141,12178,12183,22248,22258,22298,22301,22308,22320,22396,22451,22594,22933,23052,23061,23104,23149,23311,23355,23547,23633,23645,36218,36234,36291,36377,36396,36407,36446,36481,36490,36493,36505,36550,36555,36564,36616,43049,43099,43109,43114,43183,43218,43278,43483,43498,43559,43565,43566,43670,44027,44133,44226)

# 사용정보 - 조미나
SELECT
    b.oid,
    b.name,
    b.id,
    b.phone,
    b.creDateTime AS 가입일,
    a.shopRef,
    a.shopName,
    a.orderPrice,
    a.pointPrice,
    a.payPrice,
    a.payDateTime AS 사용일
FROM tbl_payShop AS a
INNER JOIN tbl_member AS b ON a.memberRef = b.oid
WHERE
    b.oid IN (819,820,821,822,824,825,840,844,847,849,850,852,853,854,855,857,858,860,861,863,1637,1638,1640,1641,1642,1643,1644,1645,1646,1648,2365,2371,2380,2399,2420,2422,2465,2498,2526,2559,2599,2618,2639,2649,2652,2658,2686,2696,2704,2708,4012,4029,4035,4043,4051,4052,4054,4057,4068,4101,4105,4107,4110,4119,4124,4137,4143,4147,4172,4196,4197,4215,4216,4217,4288,4312,4317,4350,4356,4392,4422,4426,4436,4449,4453,4457,4479,4491,4511,4538,4545,4573,4597,4654,4661,4725,4743,4756,4771,4779,4844,4853,4898,4911,4934,4946,4968,4986,5031,5044,5052,5061,5091,5138,5148,5154,5175,5200,5216,5218,5220,5237,5238,5250,5252,5337,5351,5495,5500,5524,5526,5529,5543,5580,5599,5604,5613,5650,5659,5777,5780,5797,5799,5833,5850,5868,5872,8522,8523,8573,8579,8584,8592,8622,8634,8635,8657,8686,8690,8723,8729,8731,8768,8790,8793,8821,8823,8854,8871,8885,8932,8945,8973,8997,9083,9101,9132,9154,9168,9185,9212,9224,9247,9259,9262,9266,9289,9324,9440,9523,9527,9574,9579,9612,9682,9716,9746,9748,9771,9774,10425,10512,10525,10533,10537,10547,10551,10561,10574,10591,10632,10658,10677,10711,10735,10934,10935,11038,11055,11088,11104,11122,11157,11198,11208,11228,11243,11277,11315,11323,11342,11350,11393,11411,11436,11859,11902,11937,11969,11986,11995,12038,12041,12049,12054,12073,12114,12141,12178,12183,22248,22258,22298,22301,22308,22320,22396,22451,22594,22933,23052,23061,23104,23149,23311,23355,23547,23633,23645,36218,36234,36291,36377,36396,36407,36446,36481,36490,36493,36505,36550,36555,36564,36616,43049,43099,43109,43114,43183,43218,43278,43483,43498,43559,43565,43566,43670,44027,44133,44226)
    AND a.settlementState IN (2, 3)
    AND a.useState IN (2, 3)

# 포인트 적립 정보 - 조미나
SELECT
    oid,
    memberRef,
    memberName,
    memberPhone,
    points,
    name,
    registDateTime AS 적립일
FROM tbl_pointCode 
WHERE
    memberRef IN (819,820,821,822,824,825,840,844,847,849,850,852,853,854,855,857,858,860,861,863,1637,1638,1640,1641,1642,1643,1644,1645,1646,1648,2365,2371,2380,2399,2420,2422,2465,2498,2526,2559,2599,2618,2639,2649,2652,2658,2686,2696,2704,2708,4012,4029,4035,4043,4051,4052,4054,4057,4068,4101,4105,4107,4110,4119,4124,4137,4143,4147,4172,4196,4197,4215,4216,4217,4288,4312,4317,4350,4356,4392,4422,4426,4436,4449,4453,4457,4479,4491,4511,4538,4545,4573,4597,4654,4661,4725,4743,4756,4771,4779,4844,4853,4898,4911,4934,4946,4968,4986,5031,5044,5052,5061,5091,5138,5148,5154,5175,5200,5216,5218,5220,5237,5238,5250,5252,5337,5351,5495,5500,5524,5526,5529,5543,5580,5599,5604,5613,5650,5659,5777,5780,5797,5799,5833,5850,5868,5872,8522,8523,8573,8579,8584,8592,8622,8634,8635,8657,8686,8690,8723,8729,8731,8768,8790,8793,8821,8823,8854,8871,8885,8932,8945,8973,8997,9083,9101,9132,9154,9168,9185,9212,9224,9247,9259,9262,9266,9289,9324,9440,9523,9527,9574,9579,9612,9682,9716,9746,9748,9771,9774,10425,10512,10525,10533,10537,10547,10551,10561,10574,10591,10632,10658,10677,10711,10735,10934,10935,11038,11055,11088,11104,11122,11157,11198,11208,11228,11243,11277,11315,11323,11342,11350,11393,11411,11436,11859,11902,11937,11969,11986,11995,12038,12041,12049,12054,12073,12114,12141,12178,12183,22248,22258,22298,22301,22308,22320,22396,22451,22594,22933,23052,23061,23104,23149,23311,23355,23547,23633,23645,36218,36234,36291,36377,36396,36407,36446,36481,36490,36493,36505,36550,36555,36564,36616,43049,43099,43109,43114,43183,43218,43278,43483,43498,43559,43565,43566,43670,44027,44133,44226)

# point null date 처리용 - 조미나
SELECT
    memberRef,
    buyPoints,
    reason,
    creDateTime AS 적립일
FROM tbl_pointsHistory
WHERE
    memberRef IN (819,820,821,822,824,825,840,844,847,849,850,852,853,854,855,857,858,860,861,863,1637,1638,1640,1641,1642,1643,1644,1645,1646,1648,2365,2371,2380,2399,2420,2422,2465,2498,2526,2559,2599,2618,2639,2649,2652,2658,2686,2696,2704,2708,4012,4029,4035,4043,4051,4052,4054,4057,4068,4101,4105,4107,4110,4119,4124,4137,4143,4147,4172,4196,4197,4215,4216,4217,4288,4312,4317,4350,4356,4392,4422,4426,4436,4449,4453,4457,4479,4491,4511,4538,4545,4573,4597,4654,4661,4725,4743,4756,4771,4779,4844,4853,4898,4911,4934,4946,4968,4986,5031,5044,5052,5061,5091,5138,5148,5154,5175,5200,5216,5218,5220,5237,5238,5250,5252,5337,5351,5495,5500,5524,5526,5529,5543,5580,5599,5604,5613,5650,5659,5777,5780,5797,5799,5833,5850,5868,5872,8522,8523,8573,8579,8584,8592,8622,8634,8635,8657,8686,8690,8723,8729,8731,8768,8790,8793,8821,8823,8854,8871,8885,8932,8945,8973,8997,9083,9101,9132,9154,9168,9185,9212,9224,9247,9259,9262,9266,9289,9324,9440,9523,9527,9574,9579,9612,9682,9716,9746,9748,9771,9774,10425,10512,10525,10533,10537,10547,10551,10561,10574,10591,10632,10658,10677,10711,10735,10934,10935,11038,11055,11088,11104,11122,11157,11198,11208,11228,11243,11277,11315,11323,11342,11350,11393,11411,11436,11859,11902,11937,11969,11986,11995,12038,12041,12049,12054,12073,12114,12141,12178,12183,22248,22258,22298,22301,22308,22320,22396,22451,22594,22933,23052,23061,23104,23149,23311,23355,23547,23633,23645,36218,36234,36291,36377,36396,36407,36446,36481,36490,36493,36505,36550,36555,36564,36616,43049,43099,43109,43114,43183,43218,43278,43483,43498,43559,43565,43566,43670,44027,44133,44226)
    AND ((reason LIKE "4만원권 28%") OR (reason LIKE "1만원권 50\%") OR (reason LIKE "1만원권 50퍼센트(추가)") OR (reason LIKE "1만원권 50퍼센트(추가2)"))
    AND type = 1
    AND buyPoints > 0

# 발행 코드 취소 처리
# pointCodeGroup은 수동으로 진행
UPDATE tbl_pointCode
SET
    state = 4
WHERE
    groupRef = 98
    AND state = 2

# pointCode 적립 금액 수정
# pointCodeGroup은 수동으로 진행
UPDATE tbl_pointCode
SET
    points = 10300
WHERE
    groupRef IN (99,100)
# promotion code 등록 회원 정보 - 조미나
SELECT
    code, groupRef, name, registDateTime AS 등록일, memberName, memberPhone,
    (SELECT
        creDateTime
    FROM tbl_member
        WHERE oid = a.memberRef
    ) AS 가입일
FROM tbl_pointCode AS a
WHERE
    groupRef IN (95, 96, 97)
    AND registDateTime IS NOT NULL

# 일자별 가입자 수 - 조미나
SELECT DATE(creDateTime) AS 가입일, COUNT(oid) AS 가입자수
FROM `tbl_member`
WHERE
    state = 1
    AND roles NOT LIKE "%02%"
GROUP BY DATE(creDateTime)
ORDER BY DATE(creDateTime) ASC

# 적립포인트 현황 - 김주은
# 적립 현황
SELECT DATE(creDateTime) AS 일자, SUM(accPoints) AS 적립액
FROM tbl_pointsHistory
WHERE
    type=1
GROUP BY DATE(creDateTime)
ORDER BY DATE(creDateTime) ASC

# 사용 현황
SELECT DATE(creDateTime) AS 일자, SUM(accPoints) AS 사용액
FROM tbl_pointsHistory
WHERE
    type=2
GROUP BY DATE(creDateTime)
ORDER BY DATE(creDateTime) ASC

# 월별 가입자 수 현황 - 조미나
SELECT YEAR(creDateTime) AS 년도, MONTH(creDateTime) AS 월, COUNT(oid)
FROM tbl_member
WHERE
    state = 1
    AND creDateTime >= "2019-01-01 00:00:00"
GROUP BY YEAR(creDateTime) ASC, MONTH(creDateTime) ASC

# 일별 포인트 사용 점포 구분
SELECT YEAR(payDateTime) AS 년도, MONTH(payDateTime) AS 월,
    DAY(payDateTime) AS 일,
    SUM(orderPrice) AS 주문금액, SUM(pointPrice) AS 포인트금액, SUM(companyPoints) AS 기업포인트, SUM(payPrice) AS 카드결제
FROM tbl_payShop
WHERE  
    useState IN (2, 3)
    AND shopType = 1
    AND payDateTime >= "2019-03-01 00:00:00"
GROUP BY YEAR(payDateTime) ASC, MONTH(payDateTime) ASC,
    DAY(payDateTime) ASC

# 월별 포인트 사용 점포 구분
SELECT YEAR(payDateTime) AS 년도, MONTH(payDateTime) AS 월,
    SUM(orderPrice) AS 주문금액, SUM(pointPrice) AS 포인트금액, SUM(companyPoints) AS 기업포인트, SUM(payPrice) AS 카드결제
FROM tbl_payShop
WHERE  
    useState IN (2, 3)
    AND shopType = 1
    AND payDateTime >= "2019-01-01 00:00:00"
GROUP BY YEAR(payDateTime) ASC, MONTH(payDateTime) ASC

# 회원 가입 현황 - 월별 - 조미나
SELECT YEAR(creDateTime) AS 년도, MONTH(creDateTime) AS 월,
    COUNT(oid) AS 가입자수
FROM tbl_member
WHERE
    state = 1
GROUP BY YEAR(creDateTime) ASC, MONTH(creDateTime) ASC

# 프랜차이즈 월간 사용 내역
SELECT YEAR(useDateTime) AS 년도, MONTH(useDateTime) AS 월,
    consummerRef, SUM(orderPrice) AS 사용금액
FROM tbl_use
WHERE
    consummerRef != 0
    AND useType IN (2, 3)
GROUP BY YEAR(useDateTime), MONTH(useDateTime),
    consummerRef


# promotion 등록 회원 정보 - 조미나
SELECT member.oid, member.name, member.phone, member.id, member.osType, member.state,
    member.points, member.creDateTime, member.visitDateTime,
    code.groupRef
FROM tbl_pointCode AS code
LEFT OUTER JOIN (SELECT oid, name, phone, id, osType, state, points, creDateTime, visitDateTime
    FROM tbl_member) AS member ON member.oid = code.memberRef
WHERE
    groupRef IN (
        SELECT oid
        FROM tbl_pointCodeGroup
        WHERE
            promotionRef IN (41,47,53,54,58,60)
        )
    AND memberRef > 0

# 7, 170,39,87, 89, 14, 83

# 프랜차이즈 별 점포별 일별 매출
SELECT DATE(useDateTime) AS 사용일시, shopName, consummerRef, SUM(orderPrice) AS 사용금액, COUNT(oid) AS 사용횟수
FROM tbl_use
WHERE
    consummerRef > 0
    AND useType IN (2, 3)
    AND useDateTime >= "2017-07-19 00:00:00"
#    AND useDateTime < "2019-07-25 00:00:00"
GROUP BY DATE(useDateTime), consummerRef
ORDER BY DATE(useDateTime)

# 프랜차이즈 별 월별 매출
SELECT YEAR( useDateTime ) AS 사용년도, MONTH( useDateTime ) AS 사용월, consummerRef, shopName, SUM( orderPrice ) AS 사용금액
FROM tbl_order
WHERE consummerRef >0
    AND state =2
    AND useDateTime >= "2017-05-01 00:00:00"
GROUP BY YEAR( useDateTime ) , MONTH( useDateTime ) , consummerRef

# 프랜차이즈 별 일별 매출
SELECT DATE(useDateTime) AS 사용일시, 
        consummerRef, shopName, SUM( orderPrice ) AS 사용금액
FROM tbl_order
WHERE consummerRef >0
    AND state =2
    AND useDateTime >= "2017-05-01 00:00:00"
GROUP BY DATE(useDateTime), consummerRef

# 프랜차이즈(샐러디) 월별 매출
SELECT YEAR( useDateTime ) AS 사용년도, MONTH( useDateTime ) AS 사용월, consummerRef, shopName, SUM( orderPrice ) AS 사용금액
FROM tbl_order
WHERE shopName LIKE "%샐러디%"
    AND state =2
GROUP BY YEAR( useDateTime ) , MONTH( useDateTime ) , consummerRef

# 프랜차이즈(샐러디) 일별 매출
SELECT DATE(useDateTime) AS 사용일시, 
        consummerRef, shopName, SUM( orderPrice ) AS 사용금액
FROM tbl_order
WHERE shopName LIKE "%샐러디%"
    AND state =2
    AND useDateTime >= "2017-01-01 00:00:00"
GROUP BY DATE(useDateTime), consummerRef

# 회원 이디야 사용 경험 포함
SELECT oid, name, id, phone, creDateTime AS 가입일, gender, visitDateTime AS 최종방문일, osType, points,
    (
        SELECT count(oid)
        FROM tbl_payShop
        WHERE
            memberRef = a.oid
            AND consummerRef = 6
            AND settlementState IN (2, 3)
            AND useState IN (2, 3)
    ) AS 이디야사용횟수,
    companyRef
FROM tbl_member AS a
WHERE state = 1
GROUP BY a.oid

# 4월 포인트 이용 내역
SELECT DATE(a.payDateTime) AS 사용일, a.shopName, a.consummerRef,
    SUM(b.orderPrice) AS 주문금액, SUM(b.pointPrice) AS 포인트금액, SUM(b.buyPoints) AS 구매포인트, SUM(b.accPoints) AS 적립포인트,
    SUM(b.tampingPoints) AS 지급포인트, SUM(b.companyPoints) AS 기업포인트, SUM(b.payPrice) AS 결제금액, COUNT(a.oid) AS 사용횟수
FROM tbl_payShop AS a
INNER JOIN tbl_payment AS b ON a.paymentRef = b.oid
WHERE
    a.settlementState IN (2, 3)
    AND a.useState IN (2, 3)
    AND shopName LIKE "%샐러디%"
    AND a.payDateTime >= "2019-04-01 00:00:00"
    AND a.payDateTime < "2019-05-01 00:00:00"
GROUP BY DATE(a.payDateTime), a.consummerRef

SELECT YEAR(payDateTime) AS 사용년도, MONTH(payDateTime) AS 사용월,
 DAY(payDateTime) AS 사용일, HOUR(payDateTime) AS 사용시간, MINUTE(payDateTime) AS 사용분, COUNT(oid)
FROM tbl_payment
WHERE   settlementState IN (2, 3)
    AND useState IN (2, 3)
    AND payDateTime BETWEEN "2019-05-11" AND "2019-05-12"
GROUP BY YEAR(payDateTime), MONTH(payDateTime), DAY(payDateTime),
 HOUR(payDateTime), MINUTE(payDateTime)

 # 카드 결제 회원 수
 SELECT DATE(payDateTime) AS 결제일, COUNT(DISTINCT memberRef) AS 결제자수
 FROM tbl_payment
 WHERE
    payPrice > 0
    AND useState IN (2, 3)
    AND payDateTime >= "2019-03-01 00:00:00"
GROUP BY DATE(payDateTime) ASC

 # 카드 결제 회원 정보
SELECT id, phone, name, companyRef,
(SELECT COUNT(oid)
 FROM tbl_payment
 WHERE
    payPrice > 0
    AND memberRef = a.oid
    AND useState IN (2, 3)
    AND payDateTime >= "2019-03-01 00:00:00") AS 결제경험수
FROM tbl_member AS a
WHERE
    oid IN (
 SELECT DISTINCT memberRef
 FROM tbl_payment
 WHERE
    payPrice > 0
    AND useState IN (2, 3)
    AND payDateTime >= "2019-03-01 00:00:00"
)

# 프랜차이즈 사용량
SELECT DATE(useDateTime) AS 사용일시, 
        consummerRef,
        (CASE WHEN consummerRef > 0 THEN shopName
            ELSE "샐러디"
        END) AS 프랜차이즈,
        SUM( orderPrice ) AS 사용금액, COUNT(oid) AS 사용횟수
FROM tbl_order
WHERE 
    ( consummerRef > 0
        OR shopName LIKE "%샐러디%"
    )
    AND state =2
    AND DATE(useDateTime) BETWEEN "2019-08-01 00:00:00" AND "2019-08-31 00:00:00"
GROUP BY DATE(useDateTime), consummerRef

# 프랜차이즈 사용량 row data
SELECT oid, memberRef, memberName, memberPhone, consummerRef, shopName,
        (SELECT name
            FROM tbl_giftProducer AS p
            WHERE
                p.oid = (SELECT producerRef
                                FROM tbl_giftConsummer
                                WHERE oid = a.consummerRef
                            )
        ) AS 발행처,
        orderPrice, pointPrice, companyPoints, useDateTime AS 사용일시
FROM tbl_order AS a
WHERE 
    consummerRef > 0
    AND state =2
    AND DATE(useDateTime) BETWEEN "2019-07-01 00:00:00" AND "2019-07-31 00:00:00"

# 일별 매출액 보기
SELECT DATE(useDateTime) AS 사용일시, 
        SUM( orderPrice ) AS 사용금액, COUNT(oid) AS 사용횟수
FROM tbl_order
WHERE 
    state =2
    AND DATE(useDateTime) BETWEEN "2019-07-29 00:00:00" AND "2019-08-01 00:00:00"
GROUP BY DATE(useDateTime)

# 시간 대별 매출액 보기
SELECT DATE(useDateTime) AS 사용일시, HOUR(useDateTime) AS 사용시간, 
        SUM( orderPrice ) AS 사용금액, COUNT(oid) AS 사용횟수
FROM tbl_order
WHERE 
    state =2
    AND DATE(useDateTime) BETWEEN "2019-07-29 00:00:00" AND "2019-08-01 00:00:00"
GROUP BY DATE(useDateTime), HOUR(useDateTime)


# 등록 점포 현황
SELECT oid, id, shopName, 
    (CASE
        WHEN type = 1 THEN "로컬가맹점"
        WHEN type = 4 THEN "프랜차이즈"
    END) AS 점포종류,
    consummerName,
    shopPhone, postcode, address01, address02, longitude, latitude,
    ownerName, ownerPhone, ownerEmail,
    businessNumber, bankCode, accountNumber, accountHolder
FROM tbl_shop
WHERE
    state = 3
