SELECT promotionRef,memberRef, sum(points), (select name from tbl_promotion a where a.oid = promotionRef)as name, registDateTime as 등록일 
FROM `tbl_pointCode` 
WHERE memberRef in () and promotionRef != 303 and state =3 and registDateTime >= '2020-04-03 00:00:00'
group by promotionRef, memberRef
order by memberRef


335

select oid, memberRef, memberName, sum(points) as 총발행포인트, count(oid) as 등록한코드수
from tbl_pointCode 
where promotionRef = 335
and state =3 
group by memberRef

select promotionRef,  coun(distinct memberRef) as 등록자수,avg(count(distinct memberRef)) as 평균등록수
from tbl_pointCode 
where promotionRef = 335
and state =3 


#염혜성 프로모션 등록자 이벤트

select promotionRef,(select name from tbl_promotion where promotionRef = oid) as 프로모션, memberRef, memberName, memberPhone, (select points from tbl_member where memberRef = oid) as 포인트, count(oid) as 갯수
from tbl_pointCode
where promotionRef IN (412,413,419,421,422,424,425,432)
and state = 3
group by promotionRef, memberRef




성별

SELECT year(a.useDateTime) as 결제연도, date(a.useDateTime) as 결제일,
CASE WHEN b.gender =1
THEN '남자'
WHEN b.gender =2
THEN '여자'
ELSE '인증 안한 사람'
END AS '성별파악', 
a.consummerRef, a.shopName,
count(a.oid) as 결제횟수, sum(a.orderPrice) as 결제금액, COUNT(b.oid ) as 횟수

FROM tbl_order a
left outer join tbl_member b on b.oid = a.memberRef
WHERE
b.verification = 1 
and a.consummerRef =64 
and a.state = 2 
and a.useDateTime between  "2020-03-09 00:00:00" AND "2020-04-01 00:00:00"
group by b.gender, year(a.useDateTime), date(a.useDateTime) 
order by year(a.useDateTime), date(a.useDateTime) 


현기준 회원정보

SELECT name, phone, id, state AS 상태, points, creDateTime AS 가입일, wdDateTime AS 탈퇴일
FROM `tbl_member`
WHERE verification =1


매장 현황


SELECT oid, id, shopName, address01,
    (CASE
        WHEN state = 0 THEN "사용안함"
        WHEN state = 1 THEN "승인준비중"
        when state = 2 then "확인준비중"
        when state = 3 then "운영중"
        when state = 4 then "이용중지"
        when state = 5 then "계약해지"
        when state = 10 then "시험용점포"
    END) AS 점포상태
  	
FROM tbl_shop
WHERE consummerRef IN (3,5,6,19,22,23,34,35,36,37,38,40,41,42,43,45,47,48,49,51,52,53,54,55,56,57,58,59,61,63,64,66,69,70,71)




#바우처 미등록 17일 초과
SELECT COUNT( DISTINCT memberRef )
FROM `tbl_pointCode`
WHERE memberRef NOT
IN (

SELECT memberRef
FROM tbl_pointCode
WHERE state =3
AND registDateTime >= '2020-04-24 00:00:00'
)
AND state =3
AND registDateTime < '2020-04-24 00:00:00'
    


SELECT COUNT( DISTINCT memberRef )
FROM `tbl_pointCode`
WHERE memberRef
IN (
-- 본인인증 했고 포인트 8만 포인트 이하
SELECT oid
FROM tbl_member
WHERE verification =1
and  state =1
AND points <=80000
)
AND memberRef NOT
IN (
-- 30일 전에 등록한 적이 없는 사람들 찾기
SELECT memberRef
FROM tbl_pointCode
WHERE state =3
AND registDateTime >= '2020-03-14 00:00:00'
)
-- 30일 초과 60일 이내
AND state =3
and registDateTime > '2020-02-13 00:00:00'
AND registDateTime < '2020-03-14 00:00:00'



SELECT COUNT( DISTINCT memberRef )
FROM `tbl_pointCode`
WHERE memberRef
IN (
-- 본인인증 했고 포인트 8만 포인트 이하
SELECT oid
FROM tbl_member
WHERE verification =1
and  state =1
AND points <=80000
)
AND memberRef NOT
IN (
-- 30일 전에 등록한 적이 없는 사람들 찾기
SELECT memberRef
FROM tbl_pointCode
WHERE state =3
AND registDateTime >= '2020-02-13 00:00:00'
)
-- 30일 초과 60일 이내
AND state =3

AND registDateTime < '2020-02-13 00:00:00'



#염혜성

select memberName, 
memberPhone, 
(select id from tbl_member where memberRef = oid) as id, 
(select name from tbl_promotion where promotionRef = oid) as 프로모션, 
registDateTime as 등록일, 
(select date(creDateTime) from tbl_member where memberRef = oid) as 가입일
from tbl_pointCode
where 
promotionRef IN (472) --프로모션
and state = 3 -- 등록완료
and memberRef IN (select oid from tbl_member where creDateTime between '2020-11-27 00:00:00' and '2020-11-30 23:59:59' ) --해당 기간에 가입한 회원들만 
and registDateTime >= '2020-10-01 00:00:00' 
and registDateTime < '2020-12-05 00:00:00'


#염혜성 2
select memberName, 
memberPhone, 
(select id from tbl_member where memberRef = oid) as id, 
(select name from tbl_promotion where promotionRef = oid) as 프로모션, 
registDateTime as 등록일, 
code as 코드,
points
from tbl_pointCode
where 
promotionRef IN (442,459)
--and groupRef = 865 --864 10만원 --프로모션
and state = 3 -- 등록완료
and registDateTime >= '2020-09-01 00:00:00' 
and registDateTime < '2020-12-10 00:00:00'


#염헤성
#바우처 정산
SELECT oid,(select name from tbl_promotion where promotionRef = oid) as 프로모션, 
promotionRef, code, (
SELECT groupName
FROM tbl_pointCodeGroup
WHERE oid = pcode.groupRef
) AS 금액권명, points, registDateTime AS 등록일시
FROM `tbl_pointCode` AS pcode
WHERE `promotionRef` 448
IN (select oid from tbl_promotion where sellerRef = 2)
AND state =3
AND registDateTime >= '2020-10-01 00:00:00'
AND registDateTime < '2020-11-01 00:00:00' 


#혹시나 하는 페이즈
SELECT oid,(select name from tbl_promotion where promotionRef = oid) as 프로모션, 
promotionRef, code, (
SELECT groupName
FROM tbl_pointCodeGroup
WHERE oid = pcode.groupRef
) AS 금액권명, points, registDateTime AS 등록일시
FROM `tbl_pointCode` AS pcode
WHERE `promotionRef`
IN (select oid from tbl_promotion where sellerRef = 4)
AND state =3
AND registDateTime >= '2020-11-01 00:00:00'
AND registDateTime < '2020-12-01 00:00:00' 



--부정사용
-- 바우처
select (select name from tbl_promotion where promotionRef = oid) as 프로모션, memberName, memberPhone, (select id from tbl_member where memberRef = oid) as id, sum(points) as 등록금액, count(oid) as 등록횟수
from tbl_pointCode
where promotionRef IN (324,326,327,328,331,334,335,337,338,342,345,346,347,352)
and state =3
group by promotionRef, memberRef
having  등록금액 >= 5000000 and  등록횟수 >= 5

-- 결제이력
select memberName, (select phone from tbl_member where memberRef = oid) as phone, shopName, useDateTime as 결제일시, orderPrice as 결제금액
from tbl_order
where memberRef In (select oid from tbl_member where phone IN (01092733232,01040223451,01049198620,01054455698,01040223451,01054455698,01089517185,01030697940,01092733232,01054455698,01089517185,01089517185,01026575932,01095916402,01089517185,01092733232))
and state = 2
and useDateTime between '2020-02-01 00:00:00' and '2020-05-13 00:00:00'
order by memberRef


-- 김대용 헌혈

SELECT promotionRef, (
SELECT name
FROM tbl_promotion
WHERE promotionRef = oid
) AS 프로모션, memberRef, memberName, registDateTime
FROM `tbl_pointCode`
WHERE 
memberRef
IN ( select memberRef from tbl_pointCode where promotionRef IN (373) and state =3 and registDateTime >= '2020-11-27 00:00:00'
)
AND state =3

GROUP BY memberRef



select count(oid) 
from tbl_member 
where 
oid IN (select memberRef from tbl_pointCode where promotionRef IN (504,505) and state =3 and registDateTime >= '2020-11-27 00:00:00') 
and creDateTime >= '2020-11-27 00:00:00';

#헌혈바우처 등록일
 select (

SELECT name
FROM tbl_promotion
WHERE promotionRef = oid
) AS 프로모션, memberRef, memberName, registDateTime  
 from tbl_pointCode 
 where promotionRef = 319 and state =3 and registDateTime >= '2020-06-30 00:00:00' and registDateTime < '2020-07-31 00:00:00'


#박미성/노규석 눈물의 똥꼬쇼
select a.memberRef, a.memberName,(select sum(pointPrice) from tbl_order b where a.memberRef = b.memberRef and state = 2 and b.useDateTime <= '2020-04-29 23:59:59' ) as 사용금액, 
SUM( a.points ) as 총등록, SUM( a.salePrice )as 할인율합, (1-(sum(a.salePrice)/sum(a.points))) as 할인율, (select count(oid) from tbl_order b where  a.memberRef = b.memberRef and state = 2 and consummerRef >0 and companyPoints= 0 and payPrice = 0 and b.useDateTime <= '2020-04-29 23:59:59' ) as  시용횟수, count(a.oid) as 드옭횟수
from tbl_pointCode a
where a.memberRef IN
(select oid from tbl_member where state =1 and verification= 1 and creDateTime between '2019-08-01' and '2019-08-31 23:59:59' )
and a.state = 3
and a.registDateTime <= '2020-04-29 23:59:59'
group by a.memberRef
limit 30


SELECT  
     h.code as code, 
     h.point as point, 
     h.creDateTime as creDateTime, 
     h.expDateTime as expDateTime, 
     m.id as id, 
     m.name as name, 
     m.phone as phone
    FROM tbl_multiPointsHistory h, tbl_member m
    WHERE h.memberRef = m.oid
    AND h.code = #{code}
    ORDER BY h.creDateTime


    #염씌 결제
SELECT concat(year(useDateTime),' 년') as year ,date(useDateTime) as 일,memberRef, memberName, (
SELECT phone
FROM tbl_member
WHERE memberRef = oid
) AS 전번, (

SELECT id
FROM tbl_member
WHERE memberRef = oid
) AS 아뒤, shopName, orderPrice, barcode
FROM tbl_order
WHERE consummerRef = 95
AND state =2
AND useDateTime >= "2020-09-28 00:00:00"
AND useDateTime < "2020-10-05 00:00:00"


36,58,64

SELECT concat(year(useDateTime),'년') ,date(useDateTime) as 일,memberRef, sum(orderPrice) as 결제총액, count(oid) as 결제횟수
FROM tbl_order
WHERE consummerRef =64
AND state =2
AND useDateTime
BETWEEN "2020-0-23 00:00:00"
AND "2020-04-30 23:59:59"


-- 1,2,3번은 ___원 이상 결제 및 N회 이상 결제한 고객을 뽑아주면 되요
-- 성함, 연락처, 아이디, 가입일, 탈퇴일, 결제한금액, 횟수,보유포인트

-- 기준 : 최근 3개월 4/1~6/29

-- 1. 카페&디저트 브랜드에서 230,000원 이상/15회 이상 결제한 고객 
-- 2. 아시안 브랜드에서 600,000원 이상 결제 고객/ 10회 이상 결제
-- 3. 웨스턴 브랜드에서 600,000원 이상 결제한 고객 /10회 이상 결제
-- 4. 아시안/웨스턴/카페&디저트 각 10회이상 결제한 고객 
-- 5. 아시안/웨스턴/카페&디저트에서 2,000,000원 이상 결제한 고객
-- 6. 전체 브랜드(라이프&제외)에서 가장 많이 결제한 고객 (10명까지) 


SELECT b.memberRef, a.name, a.phone, a.id, a.creDateTime, a.wdDateTime, SUM( b.orderPrice ) , COUNT( b.oid ) , a.points
FROM tbl_order b
LEFT OUTER JOIN tbl_member a ON a.oid = b.memberRef
WHERE b.consummerRef
IN (
SELECT oid
FROM tbl_giftConsummer
WHERE category LIKE 'asian'
)
AND b.state =2
AND b.useDateTime
BETWEEN '2020-04-01 00:00:00'
AND '2020-06-29 23:59:59'
group by memberRef 
having sum(b.orderPrice) >= 600000 and count(b.oid) > 9;



#구독자 정보
select a.oid,a.phone, a.name, a.creDateTime, b.registDateTime
from tbl_member a
left outer join tbl_vip b on b.recommendee = a.oid
where phone IN ()

#구독 정보
select a.oid,a.phone, a.name, a.creDateTime as 가입일, b.createTime as 구독가입일, b.membershipState as 구독상태, b.subscriptionState, a.state, 
from tbl_member a
left outer join tbl_vip b on a.oid = b.recommendee
where a.phone in ()


select a.oid,a.phone, a.name, a.creDateTime as 가입일, b.createTime as 구독가입일, a.visitDateTime, b.membershipState as 구독상태, b.subscriptionState, a.state, b.joinChannel,date(c.completeDateTime) as 결제일,
sum(c.paycoPrice) as 결제금액,
(select count(d.code) from tbl_vip d where d.recommender = a.oid and recommendee is not null) as 등록피초청, 
(select count(d.code) from tbl_vip d where d.recommender = a.oid) as 초대권수
from tbl_member a
left outer join tbl_benefitUser b on b.oid = a.oid 
left outer join tbl_benefitPayment c on c.memberID = a.oid
where a.phone in (01045037570)
and c.state like 'complete'
and c.completeDateTime >= '2020-07-07' and c.completeDateTime < '2020-07-14'
group by a.oid,date(c.completeDateTime)



select a.oid,a.phone, a.creDateTime as 가입일, b.createTime as 구독가입일, a.name,
(select channel from tbl_vip d where d.recommendee = a.oid) as 초대권수, b.membershipState as 구독상태, b.subscriptionState, a.state, a.visitDateTime,
(select count(d.code) from tbl_vip d where d.recommender = a.oid) as 초대권수,
(select count(d.code) from tbl_vip d where d.recommender = a.oid and state=2) as 등록피초청
from tbl_member a
left outer join tbl_benefitUser b on b.oid = a.oid 
left outer join tbl_benefitPayment c on c.memberID = a.oid
where a.phone in (01082429810)
group by a.oid


#프로모션 등록하고 사용금액
select memberRef, memberName, (select phone from tbl_member where memberRef = oid) as phone, sum(pointPrice) as 총사용머지머니
from tbl_order
where memberRef IN (select memberRef from tbl_pointCode where promotionRef IN (380,381) and state =2 )
and state = 2
group by memberRef




#송훈 잠바쥬스 등등
80,94,95,96,97
95,96,97 파리, 던킨,파스
select year(useDateTime), date(useDateTime), shopName, sum(pointPrice) as 머지머니, SUM(orderPrice) as 머지플러스
from tbl_order a
left outer join tbl_benefitPayment b on a.barcode = b.code
where 
consummerRef IN (95,96,97) and a.state =2 and b.state like 'complete'
and useDateTime >= '2020-06-29' and useDateTime < '2020-08-18'
group by year(useDateTime), date(useDateTime), consummerRef

select franchiseID, sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(oid) as 결제횟수
from tbl_benefitPayment
where franchiseID IN (95,96,97)
and state like 'complete'
and completeDateTime >= '2020-08-18 00:00:00' 
and completeDateTime < '2020-10-07 00:00:00'
group by franchiseID

union all

select  consummerRef,shopName, sum(pointPrice) as 머지머니, count(oid) as 결제횟수
from tbl_order a
where 
consummerRef IN (95,96,97) and a.state =2
and pointPrice > 0
and useDateTime >= '2020-08-18' and useDateTime < '2020-10-07'
group by consummerRef



#브랜드별 객단가

SELECT YEAR( useDateTime ) AS 사용년도, MONTH( useDateTime ) AS 일별, consummerRef, shopName, SUM( pointPrice ) AS 사용금액, COUNT( oid )
FROM tbl_order
WHERE consummerRef >0
AND state
IN ( 2 )
AND pointPrice >0
AND useDateTime >= '2020-07-01 00:00:00'
AND useDateTime < '2020-07-27 00:00:00'
GROUP BY YEAR( useDateTime ) , MONTH( useDateTime ) , consummerRef




#탈퇴회원 정보

SELECT m.oid, m.name, m.id, m.phone, m.points AS 잔여포인트,  ifnull(t.q, 0) AS 충전포인트, m.creDateTime, m.wdDateTime
FROM tbl_order o, (

SELECT memberRef, SUM( buyPoints ) AS q
FROM tbl_pointsHistory
WHERE memberRef
IN ( select oid 
from tbl_member 
where state IN ( 3,4,5) )
AND totalPoints =0
AND TYPE =1
AND kind =3
GROUP BY memberRef
)t, (

SELECT oid, name, id, phone, points, creDateTime, wdDateTime
FROM tbl_member
WHERE oid
IN ( select oid 
from tbl_member 
where state IN ( 3,4,5))
) m

WHERE o.memberRef = m.oid
AND o.memberRef = t.memberRef
AND o.state =2

group by m.oid


SELECT a.oid, a.name, a.id, a.phone, a.points as 잔여, a.creDateTime, a.wdDateTime , (select sum(buyPoints) FROM tbl_pointsHistory where a.oid = memberRef AND totalPoints =0
AND TYPE =1
AND kind =3)충천
from tbl_member a
WHERE state IN (3,4,5)

select memberRef,sum(buyPoints) 
FROM tbl_pointsHistory where memberRef IN (select oid 
from tbl_member 
where state IN ( 3,4,5))
AND totalPoints =0
AND TYPE =1
AND kind =3충천


#마지막 결제
SELECT q.useDateTime, q.memberRef, q.shopName, q.orderPrice, COUNT( q.memberRef )
FROM (

SELECT useDateTime, memberRef, shopName, orderPrice
FROM tbl_order
WHERE memberRef
IN ( select oid 
from tbl_member 
where state IN ( 3,4,5) )
AND state =2
ORDER BY oid DESC
)q
GROUP BY q.memberRef


select a.oid, ifnull(count(b.oid),0) as 결제횟수
from tbl_member a
join tbl_order b on a.oid = b.memberRef
WHERE a.state IN (3,4,5)
and b.state = 2
group by a.oid
order by 결제횟수 asc



# CU
123,38,95
122 아트박스

79 cu

176 GS

6,63,86,103,37,102
select year(useDateTime) as year, date(useDateTime) as date, shopName, sum(pointPrice) as 머지머니, count(distinct memberRef) as count
from tbl_order 
where 
consummerRef IN (176)
and state =2
and pointPrice>0
and useDateTime >= '2020-12-01 00:00:00' 
and useDateTime < '2020-12-21 00:00:00'
group by year(useDateTime), date, consummerRef

#CU 
-- case when paymentType like 'menu' then '메뉴' 
--     when paymentType like 'normal' then '총액' end as 구분

select year(completeDateTime) as year, date(completeDateTime) as date, franchiseID,paymentType,(select name from tbl_giftConsummer where oid = franchiseID) as 상호명
 ,sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(distinct memberRef) as count
from tbl_benefitPayment
where state like 'complete'
and franchiseID IN (79)
and completeDateTime >= '2020-12-01 00:00:00' 
and completeDateTime < '2020-12-11 00:00:00'
group by year, date, franchiseID

#월별 등록 머지머니/사용머지머니

select year(useDateTime), month(useDateTime), sum(pointPrice)
from tbl_order
where state =2 
and date_format(useDateTime, '%Y') = '2020'
group by year(useDateTime), month(useDateTime);

select year(registDateTime), month(registDateTime), sum(points), count(oid) 
from tbl_pointCode
where state =3 
and date_format(registDateTime, '%Y') = '2020'
group by year(registDateTime), month(registDateTime)


#일별 신규 
SELECT year(creDateTime) ,date(creDateTime), count(oid) FROM `tbl_member` WHERE state = 1 and creDateTime >= '2020-10-01' and creDateTime < '2020-11-01'
group by year(creDateTime) ,date(creDateTime)



# 월별 가입자
select year(creDateTime) as year, month(creDateTime) as month, count(oid) as count
from tbl_member 
where verification = 1
and creDateTime < '2020-01-01'

union

select year(creDateTime) as year, month(creDateTime) as month, count(oid) as count
from tbl_member 
where verification = 1
and creDateTime >= '2020-01-01'
and creDateTime < '2020-10-01'
group by year, month



#유저 통계 (가입일 기준)
select year(creDateTime) year, month(creDateTime) month ,case when state = 1 then '활성' when state = 2 then '휴면' else '탈퇴' end as 상태, concat_ws((count(oid)),'명') as 명수
from tbl_member 
where creDateTime >= '2020-07-01'
and creDateTime < '2020-10-01'
group by year, month, state


엔터 식스 제외 결제 횟수 및 금액
select year(completeDateTime) as year, date(completeDateTime) as date, 
memberID, 
(select name from tbl_member where oid = memberID) as name, 
(select phone from tbl_member where oid = memberID) as phone, 
franchiseID,(select name from tbl_giftConsummer where oid = franchiseID) as 상호명
,sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(oid) as count
from tbl_benefitPayment
where state like 'complete'
and memberID IN (select recommendee from tbl_vip where channel like '머지랑엔터랑' and state =2)
and franchiseID NOT IN (169)
and completeDateTime >= '2020-11-12 00:00:00' 
and completeDateTime < '2020-11-24 00:00:00'
group by year, month, memberID, franchiseID



select year(completeDateTime) as year, date(completeDateTime) as date, 
franchiseID,(select name from tbl_giftConsummer where oid = franchiseID) as 상호명, count(distinct memberID) as count
from tbl_benefitPayment
where state like 'complete'
and memberID IN (select recommendee from tbl_vip where channel like '머지랑엔터랑' and state =2)
and franchiseID NOT IN (169)
and completeDateTime >= '2020-11-12 00:00:00' 
and completeDateTime < '2020-11-24 00:00:00'
group by year, date, franchiseID




select  year(membershipStartTime) year, date(membershipStartTime) date1, date(membershipExpireTime) date2, count(oid)
from tbl_benefitUser
where oid IN (select recommendee from tbl_vip where channel like '머지랑엔터랑' and state =2)
and membershipState like 'disable'

group by year,date2