/*
위에서 부터 순서대로


페이즈
스마트콘
머지직연동
케이티
즐거운
슈퍼콘
엠트웰브


*/



select 
year(completeDateTime) as year, month(completeDateTime) as month, sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(oid) as count
from tbl_benefitPayment
where state like 'complete'
and franchiseID IN (select oid from tbl_giftConsummer where producerRef = 1)
and completeDateTime >= '2020-12-11 00:00:00' 
and completeDateTime < '2020-12-16 00:00:00'
group by year, month

union

select 
year(completeDateTime) as year, month(completeDateTime) as month, sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(oid) as count
from tbl_benefitPayment
where state like 'complete'
and franchiseID IN (select oid from tbl_giftConsummer where producerRef = 2)
and completeDateTime >= '2020-12-11 00:00:00' 
and completeDateTime < '2020-12-16 00:00:00'
group by year, month

union

select 
year(completeDateTime) as year, month(completeDateTime) as month, sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(oid) as count
from tbl_benefitPayment
where state like 'complete'
and franchiseID IN (select oid from tbl_giftConsummer where producerRef = 3)
and completeDateTime >= '2020-12-11 00:00:00' 
and completeDateTime < '2020-12-16 00:00:00'
group by year, month

union

select 
year(completeDateTime) as year, month(completeDateTime) as month, sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(oid) as count
from tbl_benefitPayment
where state like 'complete'
and franchiseID IN (select oid from tbl_giftConsummer where producerRef = 4)
and completeDateTime >= '2020-12-11 00:00:00' 
and completeDateTime < '2020-12-16 00:00:00'
group by year, month

union


select 
year(completeDateTime) as year, month(completeDateTime) as month, sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(oid) as count
from tbl_benefitPayment
where state like 'complete'
and franchiseID IN (select oid from tbl_giftConsummer where producerRef = 6)
and completeDateTime >= '2020-12-11 00:00:00' 
and completeDateTime < '2020-12-16 00:00:00'
group by year, month

union

select 
year(completeDateTime) as year, month(completeDateTime) as month, sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(oid) as count
from tbl_benefitPayment
where state like 'complete'
and franchiseID IN (select oid from tbl_giftConsummer where producerRef = 7)
and completeDateTime >= '2020-12-11 00:00:00' 
and completeDateTime < '2020-12-16 00:00:00'
group by year, month


union

select 
year(completeDateTime) as year, month(completeDateTime) as month, sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(oid) as count
from tbl_benefitPayment
where state like 'complete'
and franchiseID IN (select oid from tbl_giftConsummer where producerRef = 8)
and completeDateTime >= '2020-12-11 00:00:00' 
and completeDateTime < '2020-12-16 00:00:00'
group by year, month;



#############################################

CU


##########################################



select year(completeDateTime) as year, date(completeDateTime) as date, franchiseID,paymentType,(select name from tbl_giftConsummer where oid = franchiseID) as 상호명
 ,sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(oid) as count
from tbl_benefitPayment
where state like 'complete'
and franchiseID IN (79)
and completeDateTime >= '2020-12-01 00:00:00' 
and completeDateTime < '2020-12-11 00:00:00'
group by year, date, franchiseID
