123,38,95
122 아트박스

79 cu

176 GS

6,63,86,103,37,102

/* 

머지머니 
consummerRef와 날짜만 바꿔주면 된다.



*/

select year(useDateTime) as year, date(useDateTime) as date, shopName, sum(pointPrice) as 머지머니, count(distinct memberRef) as count
from tbl_order 
where 
consummerRef IN (176)
and state =2
and pointPrice>0
and useDateTime >= '2020-12-01 00:00:00' 
and useDateTime < '2020-12-21 00:00:00'
group by year(useDateTime), date, consummerRef

/* 

머지플러스
FranchiseID와 날짜만 변경하면 된다.


*/

select year(completeDateTime) as year, date(completeDateTime) as date, franchiseID,paymentType,(select name from tbl_giftConsummer where oid = franchiseID) as 상호명
 ,sum(costPrice) as 원가, sum(salePrice) as 할인받은금액, sum(paycoPrice) as 실결제금액, count(distinct memberRef) as count
from tbl_benefitPayment
where state like 'complete'
and franchiseID IN (79)
and completeDateTime >= '2020-12-01 00:00:00' 
and completeDateTime < '2020-12-11 00:00:00'
group by year, date, franchiseID
